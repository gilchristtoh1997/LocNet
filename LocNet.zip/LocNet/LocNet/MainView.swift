//
//  MainView.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/11/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class MainView: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.red
        // Do any additional setup after loading the view.
        setupViews()
    }
    
    var SettingsButton: UIButton = {
        let sButton = UIButton()
        sButton.setTitle("Settings", for: .normal)
        sButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        sButton.titleLabel?.textColor =  UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        sButton.titleLabel?.textAlignment = .center
        sButton.layer.borderWidth = 1
        sButton.layer.cornerRadius = 10
        sButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        sButton.translatesAutoresizingMaskIntoConstraints = false
        return sButton
    }()
    
    var ConnectionButton: UIButton = {
        let conButton = UIButton()
        conButton.setTitle("Connection", for: .normal)
        conButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        conButton.titleLabel?.textColor =  UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        conButton.titleLabel?.textAlignment = .center
        conButton.layer.borderWidth = 1
        conButton.layer.cornerRadius = 10
        conButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        conButton.translatesAutoresizingMaskIntoConstraints = false
        return conButton
    }()
    
    var textLabel: UILabel = {
        let nameLabel = UILabel()
        nameLabel.text = "Home"
        nameLabel.font = UIFont(name: "Helvetica Neue", size: 30)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return nameLabel
    }()
    
    func setupViews()
    {
        view.addSubview(textLabel)
        view.addSubview(SettingsButton)
        view.addSubview(ConnectionButton)
        
        textLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 50).isActive = true
        textLabel.centerXAnchor.constraint(equalTo: view.leadingAnchor, constant: 50).isActive = true
        
        SettingsButton.topAnchor.constraint(equalTo: textLabel.bottomAnchor, constant: 50).isActive = true
        SettingsButton.centerXAnchor.constraint(equalTo: view.leadingAnchor, constant: 40).isActive = true
        
        ConnectionButton.topAnchor.constraint(equalTo: textLabel.bottomAnchor, constant: 50).isActive = true
        ConnectionButton.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
}
