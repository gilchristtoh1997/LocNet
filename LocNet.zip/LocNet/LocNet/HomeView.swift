//
//  HomeView.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/11/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class HomeView: UIViewController{

    var triggerButton: UIButton!
    var mainView: UIView!
    var imageArray = [UIImage]()
    var currentX: CGFloat = 0 // holds the current x position in the scrollView
    var leftTaps: Int = 1
    var rightTaps: Int = 1
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        setupImagesInScrollView()
        // Do any additional setup after loading the view.
    }
    
    var gotoSettingsButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "settings"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 20
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    var gotoMessageButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "messaging"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 20
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    var appLogoImageView: UIImageView = {
        let ImageView = UIImageView()
        ImageView.image = UIImage(named: "locnet")
        ImageView.contentMode = .scaleAspectFit
        ImageView.translatesAutoresizingMaskIntoConstraints = false
        ImageView.clipsToBounds = true
        ImageView.isUserInteractionEnabled = true
        return ImageView
    }()
    
    var userCellImageView: UIImageView = {
        let ImageView = UIImageView()
        ImageView.image = UIImage(named: "dummy")
        ImageView.contentMode = .scaleAspectFit
        ImageView.translatesAutoresizingMaskIntoConstraints = false
        ImageView.clipsToBounds = true
        ImageView.isUserInteractionEnabled = true
        ImageView.layer.borderWidth = 1
        ImageView.layer.cornerRadius = 10
        ImageView.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        return ImageView
    }()
    
    var scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.backgroundColor = UIColor.white
        sv.layer.cornerRadius = 12
        sv.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        sv.layer.borderWidth = 1
        sv.isPagingEnabled = true
        sv.isUserInteractionEnabled = true
        sv.showsHorizontalScrollIndicator = true
        return sv
    }()

    
    func setupViews() {
        
        self.view.addSubview(gotoMessageButton)
        self.view.addSubview(gotoSettingsButton)
        self.view.addSubview(appLogoImageView)
        self.view.addSubview(scrollView)
        self.view.addSubview(likeButton)
        self.view.addSubview(passButton)
        imageArray = [#imageLiteral(resourceName: "kratos"),#imageLiteral(resourceName: "cheesy"),#imageLiteral(resourceName: "music_guy"),#imageLiteral(resourceName: "gow4"), #imageLiteral(resourceName: "thanos")]
        
        gotoSettingsButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 80).isActive = true
        gotoSettingsButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        gotoSettingsButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        gotoSettingsButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        //gotoSettingsButton.addTarget(self, action: #selector(scrollToSettings), for: .touchUpInside)

        gotoMessageButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 80).isActive = true
        gotoMessageButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        gotoMessageButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        gotoMessageButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        //gotoMessageButton.addTarget(self, action: #selector(gotoConnections), for: .touchUpInside)

        appLogoImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 30).isActive = true
        appLogoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        appLogoImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        appLogoImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        let screenRect = UIScreen.main.bounds
        let screenWidth = screenRect.size.width
        let x = screenRect.origin.x
        
        scrollView.frame = CGRect(x: x + 5, y: 150, width: screenWidth - 10 , height: 550)
        
        //add a tap gesture to the screen view
        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(didTapScrollView(gridPos:))))
        
        likeButton.topAnchor.constraint(equalTo: view.bottomAnchor, constant: -140).isActive = true
        likeButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -40).isActive = true
        likeButton.widthAnchor.constraint(equalToConstant: 60).isActive = true
        likeButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        passButton.topAnchor.constraint(equalTo: view.bottomAnchor, constant: -140).isActive = true
        passButton.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 40).isActive = true
        passButton.widthAnchor.constraint(equalToConstant: 60).isActive = true
        passButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
        

    }
    func setupImagesInScrollView() {
        
        for i in 0..<imageArray.count {
            let imageView = UIImageView()
            let x = self.scrollView.frame.size.width * CGFloat(i)
            imageView.frame = CGRect(x: x, y: 0, width: self.scrollView.frame.width, height: self.scrollView.frame.height)
            imageView.clipsToBounds = true
            imageView.contentMode = .scaleToFill
            imageView.image = imageArray[i]
            
            scrollView.contentSize.width = scrollView.frame.size.width * CGFloat(i + 1)
            scrollView.contentSize.height = scrollView.frame.size.height
            scrollView.addSubview(imageView)
        }
    }
    
    
    
    @objc func didTapScrollView(gridPos: UITapGestureRecognizer) {
        let location: CGPoint = gridPos.location(in: gridPos.view)
        let centerXanchor: CGPoint = view.center
        print("current tapped point is ", location)
        print("center is ", centerXanchor)
        if(location.x < centerXanchor.x){
            if(leftTaps == 1){
                print("Sorry cant go left anymore")
            }
            else
            {
                print("User is tapping to go left")
                if(!(currentX < 0)) {
                    leftTaps-=1
                    rightTaps-=1
                    currentX -= scrollView.frame.width
                    scrollView.contentOffset = CGPoint(x: currentX, y: 0)
                    print("left taps ",leftTaps)
                }
            }
            
        }
        else {
            
            if(rightTaps < imageArray.count) {
                print("right taps ",rightTaps)
                print("User is tapping to go right")
                rightTaps += 1
                leftTaps+=1
                currentX += scrollView.frame.width
                scrollView.contentOffset = CGPoint(x: currentX, y: 0)
            }
            else if(rightTaps == imageArray.count){
                print("Sorry cant go right anymore")
            }
            
        }
    }
    
    var likeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "x_mark"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 30
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10);
        button.translatesAutoresizingMaskIntoConstraints = false
        button.adjustsImageWhenHighlighted = false
        button.setTitleColor(UIColor.clear, for: .highlighted)

        return button
    }()
    
    var passButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "blue_check_mark"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 30
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.imageEdgeInsets = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10);
        button.translatesAutoresizingMaskIntoConstraints = false
        button.adjustsImageWhenHighlighted = false
        button.backgroundColor = UIColor.clear
        return button
    }()
    @objc func gotoSettings() {
        print("Trying to go to settings")
        let settingVC = SettingsView()
        settingVC.modalPresentationStyle = .custom
        settingVC.modalTransitionStyle = .crossDissolve
        self.present(settingVC, animated: true, completion: nil)
    }
    @objc func gotoConnections() {
        print("Trying to go to connections")
        let connectionVC = ConnectionView()
        connectionVC.modalPresentationStyle = .custom
        connectionVC.modalTransitionStyle = .crossDissolve
        self.present(connectionVC, animated: true, completion: nil)
    }
    
}
