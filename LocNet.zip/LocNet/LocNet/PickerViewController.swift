//
//  PickerViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/28/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class PickerViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        // Do any additional setup after loading the view.
    }
    
    var profileImageView: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.image = UIImage(named: "dummy")
        profileImageView.contentMode = .scaleAspectFit
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.clipsToBounds = true
        return profileImageView
    }()
    
    var whatToDoLabel: UILabel = {
        let whatToDo = UILabel()
        whatToDo.numberOfLines = 2
        whatToDo.text = "Click the view above to\n select your profile image."
        whatToDo.textAlignment = .center
        whatToDo.font = UIFont(name: "Helvetica Neue", size: 20)
        whatToDo.translatesAutoresizingMaskIntoConstraints = false
        whatToDo.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        whatToDo.isUserInteractionEnabled = true
        return whatToDo
    }()
    
    func setupViews() {
        self.view.addSubview(profileImageView)
        self.view.addSubview(whatToDoLabel)
        
        profileImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 70).isActive = true
        profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        profileImageView.widthAnchor.constraint(equalToConstant: 300).isActive = true
        profileImageView.heightAnchor.constraint(equalToConstant: 300).isActive = true
        
        whatToDoLabel.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 10).isActive = true
        whatToDoLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
    
}
