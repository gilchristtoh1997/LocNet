//
//  UILabelExt.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/1/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import Foundation
import UIKit

extension UILabel {
    
}
