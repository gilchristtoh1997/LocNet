//
//  SearchViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/26/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.prefersLargeTitles = true
        self.title = "Profile"
        // Do any additional setup after loading the view.
    }
   

}
