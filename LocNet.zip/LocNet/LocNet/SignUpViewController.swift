//
//  SignUpViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/26/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class SignUpViewController: UIViewController , UITextFieldDelegate{
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setUpViews()
        // Do any additional setup after loading the view.
    }
    
    var registerLabel: UILabel = {
        let registerLabel = UILabel()
        registerLabel.text = "Register to"
        registerLabel.font = UIFont(name: "Helvetica Neue", size: 30)
        registerLabel.translatesAutoresizingMaskIntoConstraints = false
        registerLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return registerLabel
    }()
    
    var logoImageView: UIImageView = {
        let logoImageView = UIImageView()
        logoImageView.image = UIImage(named: "locnet")
        logoImageView.contentMode = .scaleAspectFit
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.clipsToBounds = true
        return logoImageView
    }()
    
    var fullNameTextField: UITextField = {
        let fullName = UITextField()
        fullName.placeholder = "Full Name"
        fullName.textAlignment = .center
        fullName.layer.borderWidth = 1
        fullName.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        fullName.layer.cornerRadius = 10
        fullName.translatesAutoresizingMaskIntoConstraints = false
        fullName.autocapitalizationType = .none
        return fullName
    }()
    
    var userNameTextField: UITextField = {
        let userName = UITextField()
        userName.placeholder = "User Name"
        userName.textAlignment = .center
        userName.layer.borderWidth = 1
        userName.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        userName.layer.cornerRadius = 10
        userName.translatesAutoresizingMaskIntoConstraints = false
        userName.autocapitalizationType = .none
        return userName
    }()
    
    var emailTextField: UITextField = {
        let email = UITextField()
        email.placeholder = "Email"
        email.textAlignment = .center
        email.layer.borderWidth = 1
        email.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        email.layer.cornerRadius = 10
        email.translatesAutoresizingMaskIntoConstraints = false
        email.autocapitalizationType = .none
        return email
    }()
    
    var passwordTextField: UITextField = {
        let password = UITextField()
        password.placeholder = "Password"
        password.textAlignment = .center
        password.layer.borderWidth = 1
        password.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        password.layer.cornerRadius = 10
        password.translatesAutoresizingMaskIntoConstraints = false
        password.isSecureTextEntry = true
        password.autocapitalizationType = .none
        return password
    }()
    
    var getStartedButton: UIButton = {
        let getStartedButton = UIButton()
        getStartedButton.setTitle("Get Started", for: .normal)
        getStartedButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        getStartedButton.titleLabel?.textColor =  UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        getStartedButton.titleLabel?.textAlignment = .center
        getStartedButton.layer.borderWidth = 1
        getStartedButton.layer.cornerRadius = 10
        getStartedButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        getStartedButton.translatesAutoresizingMaskIntoConstraints = false
        return getStartedButton
    }()
    
    var alreadyMemberLabel: UILabel = {
        let amLabel = UILabel()
        amLabel.text = "Already a Member? Login"
        amLabel.font = UIFont(name: "Helvetica Neue", size: 20)
        amLabel.translatesAutoresizingMaskIntoConstraints = false
        amLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        amLabel.isUserInteractionEnabled = true
        return amLabel
    }()
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "^(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?(?:(?:(?:[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+(?:\\.[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+)*)|(?:\"(?:(?:(?:(?: )*(?:(?:[!#-Z^-~]|\\[|\\])|(?:\\\\(?:\\t|[ -~]))))+(?: )*)|(?: )+)\"))(?:@)(?:(?:(?:[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)(?:\\.[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)*)|(?:\\[(?:(?:(?:(?:(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))\\.){3}(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))))|(?:(?:(?: )*[!-Z^-~])*(?: )*)|(?:[Vv][0-9A-Fa-f]+\\.[-A-Za-z0-9._~!$&'()*+,;=:]+))\\])))(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?$"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func setUpViews() {
        self.view.addSubview(registerLabel)
        self.view.addSubview(logoImageView)
        self.view.addSubview(fullNameTextField)
        fullNameTextField.delegate = self
        self.view.addSubview(userNameTextField)
        userNameTextField.delegate = self
        self.view.addSubview(emailTextField)
        emailTextField.delegate = self
        self.view.addSubview(passwordTextField)
        passwordTextField.delegate = self
        getStartedButton.addTarget(self, action: #selector(getStarted), for: .touchUpInside)
        self.view.addSubview(getStartedButton)
        self.view.addSubview(alreadyMemberLabel)
        alreadyMemberLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(gotoLogin)))

        registerLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 60).isActive = true
        registerLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        logoImageView.topAnchor.constraint(equalTo: registerLabel.bottomAnchor).isActive = true
        logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        logoImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        logoImageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        
        fullNameTextField.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 40).isActive = true
        fullNameTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        fullNameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        fullNameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        fullNameTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        userNameTextField.topAnchor.constraint(equalTo: fullNameTextField.bottomAnchor, constant: 20).isActive = true
        userNameTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        userNameTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        userNameTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        userNameTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        emailTextField.topAnchor.constraint(equalTo: userNameTextField.bottomAnchor, constant: 20).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        emailTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        emailTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        emailTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        passwordTextField.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 20).isActive = true
        passwordTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        passwordTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        passwordTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        passwordTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        getStartedButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        getStartedButton.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 70).isActive = true
        getStartedButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        getStartedButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        getStartedButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        alreadyMemberLabel.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -30).isActive = true
        alreadyMemberLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
    
    @objc func gotoLogin() {
        let loginVC = LoginViewController()
        loginVC.modalPresentationStyle = .custom
        loginVC.modalTransitionStyle = .crossDissolve
        self.present(loginVC, animated: true, completion: nil)
    }
    @objc func gotoHomeScreen() {
        let homeVC =  TransitionViewController()
        homeVC.modalPresentationStyle = .custom
        homeVC.modalTransitionStyle = .crossDissolve
        self.present(homeVC, animated: true, completion: nil)
        
    }
    @objc func getStarted() {
        if fullNameTextField.text == "" || userNameTextField.text == "" || emailTextField.text == "" || passwordTextField.text == "" {
            let alertController = UIAlertController(title: "Error", message: "You missed something!! ", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
            
        }
        else if isValidEmail(testStr: emailTextField.text!)  == false {
            let alertController = UIAlertController(title: "Error", message: "Please enter a valid email", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
        
        else
        {
            Auth.auth().createUser(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
                if error != nil {
                    print("Create User failed: ", error!)
                }
                guard let uid = user?.user.uid else {
                    return
                }
                let ref =  Database.database().reference(fromURL: "https://locnet.firebaseio.com")
                
                let userRef = ref.child("users").child((uid))
                
                let values = ["Full_Name": self.fullNameTextField.text!, "User_Name": self.userNameTextField.text!, "Email": self.emailTextField.text!] as [String : Any]
                
                userRef.updateChildValues(values, withCompletionBlock: { (error, ref) in
                    if error != nil {
                        print("Firbase updating failed: ", error!)
                    }
                    else {
                        self.gotoHomeScreen()
                    }
                })
                
            }
        }
        
    }
   
}
