//
//  CirculationTransition.swift
//  LocNet
//
//  Created by Gilchrist Toh on 4/19/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

protocol CircleTransitionable {
    var triggerButton: UIButton { get }
    var mainView: UIView { get }
}
class CirculationTransition: NSObject, UIViewControllerAnimatedTransitioning  {
    
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?)
        -> TimeInterval {
            return 0.5
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        //make some magic happen
        
    }
    
    
}
