//
//  SettingsVC.swift
//  LocNet
//
//  Created by Gilchrist Toh on 4/20/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class SettingsVC: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        // Do any additional setup after loading the view.
    }
    func setupViews() {
        view.addSubview(doneButton)
        view.addSubview(vcTitle)
        view.addSubview(seperator)
        doneButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 45).isActive = true
        doneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30).isActive = true
        doneButton.addTarget(self, action: #selector(done), for: .touchUpInside)
        
        vcTitle.topAnchor.constraint(equalTo: view.topAnchor, constant: 50).isActive = true
        vcTitle.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        seperator.topAnchor.constraint(equalTo: vcTitle.bottomAnchor, constant: 20).isActive = true
        seperator.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        seperator.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        seperator.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        seperator.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    var doneButton: UIButton = {
        let dbutton = UIButton()
        dbutton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        dbutton.setTitle("Done", for: .normal)
        dbutton.titleLabel?.textAlignment = .center
        dbutton.layer.borderColor = UIColor.clear.cgColor
        dbutton.translatesAutoresizingMaskIntoConstraints = false
        return dbutton
    }()
    
    var vcTitle: UILabel = {
        let title = UILabel()
        title.text = "Settings"
        title.font = UIFont(name: "Helvetica Neue", size: 20)
        title.translatesAutoresizingMaskIntoConstraints = false
        title.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return title
    }()
    
    var seperator: UIView = {
        let seperator = UIView()
        seperator.backgroundColor = UIColor.lightGray
        seperator.translatesAutoresizingMaskIntoConstraints = false
        return seperator
    }()

    @objc func done() {
        self.dismiss(animated: true, completion: nil)
    }


}
