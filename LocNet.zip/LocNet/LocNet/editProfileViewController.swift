//
//  editProfileViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 4/20/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class editProfileViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate  {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 9
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let myCell = collectionView.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath)
        myCell.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        myCell.layer.shadowColor = UIColor.lightGray.cgColor
        myCell.layer.shadowOpacity = 1
        myCell.layer.shadowRadius = 2
        let viewBorder = CAShapeLayer()
        viewBorder.strokeColor = UIColor.lightGray.cgColor
        viewBorder.fillColor = nil
        viewBorder.lineDashPattern = [NSNumber(value: 2), NSNumber(value: 2)]
        viewBorder.frame = myCell.bounds
        viewBorder.path = UIBezierPath(rect: myCell.bounds).cgPath
        myCell.layer.addSublayer(viewBorder)
        
        myCell.addSubview(addRemoveButton)
        addRemoveButton.bottomAnchor.constraint(equalTo: myCell.bottomAnchor, constant: 5).isActive = true
        addRemoveButton.trailingAnchor.constraint(equalTo: myCell.trailingAnchor).isActive = true
        addRemoveButton.widthAnchor.constraint(equalToConstant: 50).isActive = true
        addRemoveButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        
        return myCell
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0 // This is the minimum inter item spacing, can be more
    }
    lazy var collection: UICollectionView = {
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 20, left: 10, bottom: 10, right: 10)
        layout.itemSize = CGSize(width: 100, height: 120)
        
        let myCollectionView = UICollectionView(frame: self.imagesView.bounds, collectionViewLayout: layout)
        myCollectionView.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        myCollectionView.translatesAutoresizingMaskIntoConstraints = false
        return myCollectionView
    }()
    override func viewDidAppear(_ animated: Bool) {
        scrollView.contentSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height)
    }
    override func viewDidLayoutSubviews() {
        scrollView.contentSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        scrollView.contentSize = CGSize(width: self.view.frame.width, height: self.view.frame.height)
        setupViews()
        collection.dataSource = self
        collection.delegate = self
        collection.register(MyCollectionViewCell.self, forCellWithReuseIdentifier: "myCell")
        

    }

    lazy var scrollView: UIScrollView = {
        let sv = UIScrollView(frame: UIScreen.main.bounds)
        sv.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        sv.isPagingEnabled = true
        sv.isScrollEnabled = true
        sv.translatesAutoresizingMaskIntoConstraints = false
        sv.contentSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height)
        return sv
    }()
    func setupViews() {
        
        view.addSubview(doneButton)
        doneButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 45).isActive = true
        doneButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -30).isActive = true
        doneButton.addTarget(self, action: #selector(done), for: .touchUpInside)
        
        
        view.addSubview(vcTitle)
        vcTitle.topAnchor.constraint(equalTo: view.topAnchor, constant: 50).isActive = true
        vcTitle.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        view.addSubview(seperator)
        seperator.topAnchor.constraint(equalTo: vcTitle.bottomAnchor, constant: 20).isActive = true
        seperator.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        seperator.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        seperator.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        seperator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        
        view.addSubview(scrollView)
        scrollView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        scrollView.topAnchor.constraint(equalTo: seperator.bottomAnchor).isActive = true
        scrollView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        scrollView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        
        

        scrollView.addSubview(imagesView)
        imagesView.topAnchor.constraint(equalTo: scrollView.topAnchor).isActive = true
        imagesView.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        imagesView.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        imagesView.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        imagesView.heightAnchor.constraint(equalToConstant: 420).isActive = true
        
        self.imagesView.addSubview(collection)
        collection.topAnchor.constraint(equalTo: imagesView.topAnchor).isActive = true
        collection.leadingAnchor.constraint(equalTo: imagesView.leadingAnchor).isActive = true
        collection.trailingAnchor.constraint(equalTo: imagesView.trailingAnchor).isActive = true
        collection.bottomAnchor.constraint(equalTo: imagesView.bottomAnchor).isActive = true
        
        
        scrollView.addSubview(dragLabel)
        dragLabel.topAnchor.constraint(equalTo: imagesView.bottomAnchor).isActive = true
        dragLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        dragLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        dragLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        dragLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        
        scrollView.addSubview(aboutMeLabel)
        scrollView.addSubview(aboutMeTextBox)
        scrollView.addSubview(jobLabel)
        scrollView.addSubview(jobTextBox)
        scrollView.addSubview(CompanyLabel)
        scrollView.addSubview(companyTextBox)
        scrollView.addSubview(connectIGLabel)
        scrollView.addSubview(connectIGTextBox)
        scrollView.addSubview(cityLiveLabel)
        scrollView.addSubview(cityTextBox)

        aboutMeLabel.topAnchor.constraint(equalTo: dragLabel.bottomAnchor).isActive = true
        aboutMeLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        aboutMeLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        aboutMeLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        aboutMeLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        aboutMeTextBox.topAnchor.constraint(equalTo: aboutMeLabel.bottomAnchor).isActive = true
        aboutMeTextBox.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        aboutMeTextBox.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        aboutMeTextBox.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        aboutMeTextBox.heightAnchor.constraint(equalToConstant: 70).isActive = true
        
        jobLabel.topAnchor.constraint(equalTo: aboutMeTextBox.bottomAnchor).isActive = true
        jobLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        jobLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        jobLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        jobLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        jobTextBox.topAnchor.constraint(equalTo: jobLabel.bottomAnchor).isActive = true
        jobTextBox.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        jobTextBox.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        jobTextBox.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        jobTextBox.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        CompanyLabel.topAnchor.constraint(equalTo: jobTextBox.bottomAnchor).isActive = true
        CompanyLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        CompanyLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        CompanyLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        CompanyLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        companyTextBox.topAnchor.constraint(equalTo: CompanyLabel.bottomAnchor).isActive = true
        companyTextBox.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        companyTextBox.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        companyTextBox.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        companyTextBox.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        connectIGLabel.topAnchor.constraint(equalTo: companyTextBox.bottomAnchor).isActive = true
        connectIGLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        connectIGLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        connectIGLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        connectIGLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true

        connectIGTextBox.topAnchor.constraint(equalTo: connectIGLabel.bottomAnchor).isActive = true
        connectIGTextBox.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        connectIGTextBox.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        connectIGTextBox.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        connectIGTextBox.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        cityLiveLabel.topAnchor.constraint(equalTo: connectIGTextBox.bottomAnchor).isActive = true
        cityLiveLabel.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        cityLiveLabel.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        cityLiveLabel.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        cityLiveLabel.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        cityTextBox.topAnchor.constraint(equalTo: cityLiveLabel.bottomAnchor).isActive = true
        cityTextBox.leadingAnchor.constraint(equalTo: scrollView.leadingAnchor).isActive = true
        cityTextBox.trailingAnchor.constraint(equalTo: scrollView.trailingAnchor).isActive = true
        cityTextBox.widthAnchor.constraint(equalTo: scrollView.widthAnchor).isActive = true
        cityTextBox.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        scrollView.contentSize = CGSize(width: self.view.bounds.width, height: self.view.bounds.height)

        
    }
    var dumyLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  Company"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()

    var CompanyLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  Company"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()
    var cityLiveLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  City"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()
    var cityTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 15)
        return textview
    }()
    var connectIGLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  Connect to Instagram"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()
    var dragLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "Drag to reaarange order "
        label.font = UIFont(name: "Helvetica Neue", size: 13)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .center
        label.textColor = UIColor.black
        return label
    }()
    
    var aboutMeLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  About Me"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()
    var jobLabel: UILabel = {
        let label = UILabel()
        label.backgroundColor = UIColor(red: 226.0 / 255.0, green: 231.0 / 255.0, blue: 238.0 / 255.0, alpha: 1)
        label.text = "  Job"
        label.font = UIFont(name: "Helvetica Neue", size: 15)
        label.translatesAutoresizingMaskIntoConstraints = false
        label.textAlignment = .left
        label.textColor = UIColor.black
        return label
    }()
    var jobTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 15)
        return textview
    }()
    var connectIGTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 15)
        return textview
    }()
    var companyTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 15)
        return textview
    }()
    var aboutMeTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 10)
        return textview
    }()
    var addRemoveButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = UIColor.white
        button.layer.borderColor = UIColor.black.cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    var doneButton: UIButton = {
        let dbutton = UIButton()
        dbutton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        dbutton.setTitle("Done", for: .normal)
        dbutton.titleLabel?.textAlignment = .center
        dbutton.layer.borderColor = UIColor.clear.cgColor
        dbutton.translatesAutoresizingMaskIntoConstraints = false
        return dbutton
    }()
    var vcTitle: UILabel = {
        let title = UILabel()
        title.text = "Edit Profile"
        title.font = UIFont(name: "Helvetica Neue", size: 20)
        title.translatesAutoresizingMaskIntoConstraints = false
        title.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return title
    }()
    
    var seperator: UIView = {
        let seperator = UIView()
        seperator.backgroundColor = UIColor.lightGray
        seperator.translatesAutoresizingMaskIntoConstraints = false
        return seperator
    }()
    
    var imagesView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 245, green: 245, blue: 245, alpha: 1)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
        
    }()

    @objc func done() {
        self.dismiss(animated: true, completion: nil)
    }

}

class MyCollectionViewCell: UICollectionViewCell {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.blue
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
