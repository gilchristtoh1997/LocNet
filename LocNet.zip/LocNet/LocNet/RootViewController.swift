//
//  RootViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 6/11/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit


class RootViewController: UIPageViewController, UIPageViewControllerDataSource{
    var currentIndex: Int!
    override init(transitionStyle style: UIPageViewController.TransitionStyle, navigationOrientation: UIPageViewController.NavigationOrientation, options: [UIPageViewController.OptionsKey : Any]? = nil) {
        super.init(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.dataSource = self
        
        let middle = viewcontrollerList[1]
        self.setViewControllers([middle], direction: .forward, animated: false, completion: nil)
        
        // Do any additional setup after loading the view.
    }
    lazy var viewcontrollerList: [UIViewController] = {
        let settingsVC = SettingsView()
        settingsVC.gotoHomeButton.addTarget(self, action: #selector(scrollToHomeFromSettings), for: .touchUpInside)
        let HomeVC = HomeView()
        HomeVC.gotoSettingsButton.addTarget(self, action: #selector(scrollToSettings), for: .touchUpInside)
        HomeVC.gotoMessageButton.addTarget(self, action: #selector(scrollToConnections), for: .touchUpInside)
        let connectionVC = ConnectionView()
        connectionVC.gotoHomeButton.addTarget(self, action: #selector(scrollToHomeFromConnections), for: .touchUpInside)
        return [settingsVC,HomeVC,connectionVC]
    }()
    @objc func scrollToSettings() {
        let first = viewcontrollerList.first
        self.setViewControllers([first!], direction: .reverse, animated: true, completion: nil)
    }
    @objc func scrollToHomeFromSettings() {
        let middle = viewcontrollerList[1]
        self.setViewControllers([middle], direction: .forward, animated: true, completion: nil)
    }
    @objc func scrollToHomeFromConnections() {
        let middle = viewcontrollerList[1]
        self.setViewControllers([middle], direction: .reverse, animated: true, completion: nil)
    }
    
    @objc func scrollToConnections() {
        let last = viewcontrollerList.last
        self.setViewControllers([last!], direction: .forward, animated: true, completion: nil)
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        guard let vcIndex = viewcontrollerList.index(of: viewController) else {
            return nil
        }
        let previousIndex =  vcIndex - 1
        guard previousIndex >= 0 else { return nil}
        guard viewcontrollerList.count > previousIndex else { return nil}
        return viewcontrollerList[previousIndex]
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        guard let vcIndex = viewcontrollerList.index(of: viewController) else {
            return nil
        }
        let nextIndex =  vcIndex + 1
        guard viewcontrollerList.count != nextIndex else { return nil}
        guard viewcontrollerList.count > nextIndex else { return nil}
        return viewcontrollerList[nextIndex]
    }
    

}
