//
//  SettingsView.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/11/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit
import Firebase
class SettingsView: UIViewController, UIGestureRecognizerDelegate, UITableViewDelegate, UITableViewDataSource{

    let notificationDict: [String] = ["Private Account", "Go Offline"]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch section {
        case 0:
            return 1
        case 1:
            return 2
        case 2:
            return 1
        default:
            fatalError("Unknown number of sections")
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        if indexPath.section == 0 {
            
            cell = tableView.dequeueReusableCell(withIdentifier: "profile", for: indexPath)
            cell.textLabel?.textAlignment = .center
            cell.heightAnchor.constraint(equalToConstant: 90).isActive = true
            cell.textLabel?.text = Auth.auth().currentUser?.displayName
            cell.selectionStyle = .none
            cell.separatorInset = .zero
            
            let cellImg: UIImageView = UIImageView(frame: CGRect(x: 10, y: 15, width: 60, height: 60))
            cellImg.layer.borderColor = UIColor.black.cgColor
            cellImg.layer.borderWidth = 1
            cellImg.clipsToBounds = true
            cellImg.layer.cornerRadius = 30
            cell.accessoryType = .disclosureIndicator

            cellImg.image = UIImage(named: "thanos")
            cell.addSubview(cellImg)
            return cell
        }
        else if indexPath.section == 1 {
            cell = tableView.dequeueReusableCell(withIdentifier: "notification", for: indexPath)
            cell.selectionStyle = .none
            cell.separatorInset = .zero
            cell.textLabel?.text = notificationDict[indexPath.row]
        }
        else if indexPath.section == 2 {
            cell = tableView.dequeueReusableCell(withIdentifier: "help", for: indexPath)
            cell.selectionStyle = .none
            cell.accessoryType = .disclosureIndicator
            cell.separatorInset = .zero
            cell.textLabel?.text = "Contact Us"
            cell.isUserInteractionEnabled = true
            cell.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(gotoContactUs)))
            
        }
        return cell
    }
    @objc func gotoContactUs(){
        print("Going to contact us page")
        let contactUsVC = ContactUs()
        let navController = UINavigationController(rootViewController:self)
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        appdelegate.window!.rootViewController = navController
        navController.pushViewController(contactUsVC, animated: true)
        
    }
    let blackView = UIView()
    var imageArray = [UIImage]()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        view.addSubview(settingsButton)
        view.addSubview(profileImageView)
        view.addSubview(whitebackground)
        view.addSubview(editImageView)
        view.addSubview(infoLabel)
        view.addSubview(settingsTableView)
        settingsTableView.delegate = self
        settingsTableView.dataSource = self
        //view.addSubview(nameLabel)
        //view.addSubview(emailLabel)
        view.addSubview(gotoHomeButton)
        view.addSubview(appLogoImageView)
        blackView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissBlackView)))
        
        settingsButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 60).isActive = true
        settingsButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        settingsButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        settingsButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        settingsButton.addTarget(self, action: #selector(presentSettings), for: .touchUpInside)
        
        profileImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 150).isActive = true
        profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        profileImageView.heightAnchor.constraint(equalToConstant: 250).isActive = true
        profileImageView.widthAnchor.constraint(equalToConstant: 250).isActive = true
        profileImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(showProfile)))
        
        whitebackground.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: -60).isActive = true
        whitebackground.leadingAnchor.constraint(equalTo: profileImageView.centerXAnchor, constant: 10).isActive = true
        whitebackground.heightAnchor.constraint(equalToConstant: 90).isActive = true
        whitebackground.widthAnchor.constraint(equalToConstant: 90).isActive = true
        
        
        editImageView.centerXAnchor.constraint(equalTo: whitebackground.centerXAnchor).isActive = true
        editImageView.centerYAnchor.constraint(equalTo: whitebackground.centerYAnchor).isActive = true
        editImageView.heightAnchor.constraint(equalToConstant: 70).isActive = true
        editImageView.widthAnchor.constraint(equalToConstant: 70).isActive = true
        editImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(presentEditProfile)))
        
        infoLabel.topAnchor.constraint(equalTo: editImageView.bottomAnchor, constant: 10).isActive = true
        infoLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        settingsTableView.topAnchor.constraint(equalTo: infoLabel.bottomAnchor, constant: 5).isActive = true
        settingsTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 5).isActive = true
        settingsTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -5).isActive = true
        settingsTableView.bottomAnchor.constraint(equalTo: appLogoImageView.topAnchor, constant: -5).isActive = true
    
        
        gotoHomeButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        gotoHomeButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        gotoHomeButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        gotoHomeButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        //gotoHomeButton.addTarget(self, action: #selector(goHome), for: .touchUpInside)
        
        appLogoImageView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        appLogoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        appLogoImageView.widthAnchor.constraint(equalToConstant: 60).isActive = true
        appLogoImageView.heightAnchor.constraint(equalToConstant: 60).isActive = true
        
        settingsTableView.register(profileViewCell.self, forCellReuseIdentifier: "profile")
        settingsTableView.register(notificationsViewCell.self, forCellReuseIdentifier: "notification")
        settingsTableView.register(getHelpCell.self, forCellReuseIdentifier: "help")
        settingsTableView.tableFooterView = UIView()
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 3
    }
    func tableView(_ tableView: UITableView, willDisplayFooterView view: UIView, forSection section: Int)
    {
        let footer = UIView()
        if section == 2 {
            footer.backgroundColor = UIColor.gray
        }
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        switch section {
        case 0:
            return "Account"
        case 1:
            return "Notifications"
        case 2:
            return "Get Help"
        default:
            fatalError("Unknown number of sections")
        }
    }
    var profileImageView: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.image = UIImage(named: "cheesy")
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.layer.cornerRadius = 120
        profileImageView.layer.borderColor = UIColor.clear.cgColor
        profileImageView.layer.borderWidth = 1
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.clipsToBounds = true
        profileImageView.isUserInteractionEnabled = true
        return profileImageView
    }()
    var whitebackground: UIView = {
        let wb = UIView()
        wb.backgroundColor = UIColor.white
        wb.layer.cornerRadius = 44
        wb.layer.borderColor = UIColor.clear.cgColor
        wb.layer.borderWidth = 1
        wb.translatesAutoresizingMaskIntoConstraints = false
        return wb
    }()
    
    var settingsTableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = UIColor.white
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isScrollEnabled = false
        return tableView
    }()
    var editImageView: UIImageView = {
        let edit = UIImageView()
        edit.backgroundColor = UIColor.white
        edit.image = UIImage(named: "edit6")
        edit.contentMode = .scaleAspectFit
        edit.layer.cornerRadius = 35
        edit.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        edit.layer.borderWidth = 1
        edit.translatesAutoresizingMaskIntoConstraints = false
        edit.clipsToBounds = true
        edit.isUserInteractionEnabled = true
        return edit
    }()
    var infoLabel: UILabel = {
        let infoLabel = UILabel()
        infoLabel.text = "Tap to edit profile"
        infoLabel.font = UIFont(name: "Helvetica Neue", size: 20)
        infoLabel.translatesAutoresizingMaskIntoConstraints = false
        infoLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return infoLabel
    }()
    
    var profile: UIView = {
        let profile = UIView()
        profile.backgroundColor = UIColor.black
        profile.layer.cornerRadius = 12
        profile.layer.borderColor = UIColor.clear.cgColor
        profile.layer.borderWidth = 1
        profile.translatesAutoresizingMaskIntoConstraints = false
        return profile
    }()
    var editProfileButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = UIColor.white
        button.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        button.setTitle("Edit Profile", for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 12
        button.layer.borderColor = UIColor.black.cgColor
        //button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    var scrollView: UIScrollView = {
        let sv = UIScrollView()
        sv.backgroundColor = UIColor.black
        sv.layer.cornerRadius = 12
        sv.layer.borderColor = UIColor.clear.cgColor
        sv.layer.borderWidth = 1
        sv.isPagingEnabled = true
        return sv
    }()
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {
        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case UISwipeGestureRecognizer.Direction.right:
                print("Swiped right")
            case UISwipeGestureRecognizer.Direction.down:
                print("Swiped down")
            case UISwipeGestureRecognizer.Direction.left:
                print("Swiped left")
            case UISwipeGestureRecognizer.Direction.up:
                print("Swiped up")
            default:
                break
            }
        }
    }

    @objc func showProfile() {
        if let window = UIApplication.shared.keyWindow
        {
            imageArray = [#imageLiteral(resourceName: "kratos"),#imageLiteral(resourceName: "cheesy"),#imageLiteral(resourceName: "music_guy")]
            blackView.backgroundColor = UIColor(white: 0, alpha: 0.5)
            
            window.addSubview(blackView)
            window.addSubview(profile)
            profile.addSubview(scrollView)
            blackView.addSubview(editProfileButton)
            
            
            editProfileButton.addTarget(self, action: #selector(presentEditProfile), for: .touchUpInside)
            profile.frame = CGRect(x: 20, y: window.frame.height, width: window.frame.width - 40, height: window.frame.height)
            
            editProfileButton.frame = CGRect(x: 20, y: window.frame.height, width: window.frame.width - 40, height: 50)
            
            scrollView.frame = CGRect(x: 0, y: profile.frame.height, width: profile.frame.width, height: profile.frame.height)
            
            blackView.frame = window.frame
            blackView.alpha = 0
            
            let y_value = profileImageView.frame.origin.y
            
            for i in 0..<imageArray.count {
                let imageView = UIImageView()
                imageView.backgroundColor = UIColor.black
                let y = 650 * CGFloat(i)
                imageView.frame = CGRect(x: 0, y: y, width: self.scrollView.frame.width, height: 650)
                imageView.contentMode = .scaleToFill
                imageView.image = imageArray[i]
                
                scrollView.contentSize.height = 650 * CGFloat(i + 1)
                scrollView.addSubview(imageView)
                
            }
            
            
            UIView.animate(withDuration: 0.5, delay: 0, usingSpringWithDamping: 1, initialSpringVelocity: 1, options: .curveEaseOut, animations: {
                
                self.blackView.alpha = 1
                self.editProfileButton.frame = CGRect(x: 20, y: window.frame.height - 110, width: self.profile.frame.width, height: 50)
                self.scrollView.frame = CGRect(x: 0, y: 0, width: self.profile.frame.width, height: self.profile.frame.height)
                
                self.profile.frame = CGRect(x: 20, y: y_value, width: window.frame.width - 40, height: window.frame.height - 275)
                
                
            }, completion: nil)
            UIView.animate(withDuration: 0.5, animations: {
                
                self.blackView.alpha = 1
                self.editProfileButton.frame = CGRect(x: 20, y: window.frame.height - 110, width: self.profile.frame.width, height: 50)
                self.scrollView.frame = CGRect(x: 0, y: 0, width: self.profile.frame.width, height: self.profile.frame.height)
                
                self.profile.frame = CGRect(x: 20, y: y_value, width: window.frame.width - 40, height: window.frame.height - 275)
               
                //
            })
        }
    }
    
    var settingsButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "settings"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 20
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.clear, for: .highlighted)
        return button
    }()
    var gotoHomeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "home"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 20
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        button.setTitleColor(UIColor.clear, for: .highlighted)
        return button
    }()
    var appLogoImageView: UIImageView = {
        let ImageView = UIImageView()
        ImageView.image = UIImage(named: "locnet")
        ImageView.contentMode = .scaleAspectFit
        ImageView.translatesAutoresizingMaskIntoConstraints = false
        ImageView.clipsToBounds = true
        ImageView.isUserInteractionEnabled = true
        return ImageView
    }()
    
    @objc func goHome() {
        print("Trying to go home")
        let homeVC = HomeView()
        homeVC.modalPresentationStyle = .custom
        homeVC.modalTransitionStyle = .crossDissolve
        self.present(homeVC, animated: true, completion: nil)
    }
    @objc func presentSettings() {
        let settingsVC = SettingsVC()
        self.present(settingsVC, animated: true, completion: nil)
    }
    @objc func presentEditProfile() {
        UIView.animate(withDuration: 1.0){
            self.blackView.alpha = 0
            if let keyWindow =  UIApplication.shared.keyWindow
            {
                self.profile.frame = CGRect(x: 20, y: keyWindow.frame.height, width: keyWindow.frame.width - 40, height: keyWindow.frame.height)
                self.editProfileButton.frame = CGRect(x: 20, y: keyWindow.frame.height, width: keyWindow.frame.width - 40, height: 50)
                self.scrollView.frame = CGRect(x: 0, y: self.profile.frame.height, width: self.profile.frame.width, height: self.profile.frame.height)
            }
            
        }
        print("going to edit profile")
        let editProfile = editProfileViewController()
        self.present(editProfile, animated: true, completion: nil)
    }
    @objc func dismissBlackView()
    {
        UIView.animate(withDuration: 0.5){
            self.blackView.alpha = 0
            if let keyWindow =  UIApplication.shared.keyWindow
            {
               self.profile.frame = CGRect(x: 20, y: keyWindow.frame.height, width: keyWindow.frame.width - 40, height: keyWindow.frame.height)
               self.editProfileButton.frame = CGRect(x: 20, y: keyWindow.frame.height, width: keyWindow.frame.width - 40, height: 50)
            }

        }
        
    }

}

extension UIColor {
    static var random: UIColor {
        return UIColor(red: .random(in: 0...1),
                       green: .random(in: 0...1),
                       blue: .random(in: 0...1),
                       alpha: 1.0)
    }
}
class profileViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    
}
class notificationsViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    func setupViews() {
        addSubview(newSwitch)
        newSwitch.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -10).isActive = true
        newSwitch.centerYAnchor.constraint(equalTo: self.centerYAnchor).isActive = true
        
    }
    
    var newSwitch: UISwitch = {
        let mySwitch = UISwitch()
        mySwitch.translatesAutoresizingMaskIntoConstraints = false
        return mySwitch
    }()
}

class getHelpCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    func setupViews() {
        
    }
}
