//
//  LoginViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/23/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit
//import FBSDKCoreKit
import FBSDKLoginKit
import Firebase
import FirebaseStorage
import GoogleSignIn

class LoginViewController: UIViewController, GIDSignInUIDelegate, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        // Do any additional setup after loading the view.
    }
    
    var loginLabel: UILabel = {
        let loginLabel = UILabel()
        loginLabel.text = "Login to"
        loginLabel.font = UIFont(name: "Helvetica Neue", size: 30)
        loginLabel.translatesAutoresizingMaskIntoConstraints = false
        loginLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return loginLabel
    }()
    
    var loginLabelFacebook: UILabel = {
        let loginLabelFacebook = UILabel()
        loginLabelFacebook.text = "LOGIN WITH"
        loginLabelFacebook.font = UIFont(name: "Helvetica Neue", size: 10)
        loginLabelFacebook.translatesAutoresizingMaskIntoConstraints = false
        loginLabelFacebook.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return loginLabelFacebook
    }()
    var facebookLabel: UILabel = {
        let facebookLabel = UILabel()
        facebookLabel.text = "FACEBOOK"
        facebookLabel.font = UIFont(name: "Helvetica Neue", size: 10)
        facebookLabel.translatesAutoresizingMaskIntoConstraints = false
        facebookLabel.textColor = UIColor(red: 109/255.0, green: 132/255.0, blue: 180/255.0, alpha: 1)
        return facebookLabel
    }()
    var googleLabel: UILabel = {
        let googleLabel = UILabel()
        googleLabel.text = "GOOGLE"
        googleLabel.font = UIFont(name: "Helvetica Neue", size: 10)
        googleLabel.translatesAutoresizingMaskIntoConstraints = false
        googleLabel.textColor = UIColor(red: 29/255.0, green: 202/255.0, blue: 255/255.0, alpha: 1)
        return googleLabel
    }()
    var loginLabelTwitter: UILabel = {
        let loginLabelTwitter = UILabel()
        loginLabelTwitter.text = "LOGIN WITH"
        loginLabelTwitter.font = UIFont(name: "Helvetica Neue", size: 10)
        loginLabelTwitter.translatesAutoresizingMaskIntoConstraints = false
        loginLabelTwitter.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return loginLabelTwitter
    }()
    var logoImageView: UIImageView = {
        let logoImageView = UIImageView()
        logoImageView.image = UIImage(named: "locnet")
        logoImageView.contentMode = .scaleAspectFit
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.clipsToBounds = true
        return logoImageView
    }()
    
    var googleLogoImageView: UIImageView = {
        let googleLogoImageView = UIImageView()
        googleLogoImageView.image = UIImage(named: "google")
        googleLogoImageView.contentMode = .scaleAspectFit
        googleLogoImageView.layer.cornerRadius = 44
        googleLogoImageView.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        googleLogoImageView.layer.borderWidth = 1
        googleLogoImageView.translatesAutoresizingMaskIntoConstraints = false
        googleLogoImageView.clipsToBounds = true
        googleLogoImageView.isUserInteractionEnabled = true
        return googleLogoImageView
    }()
    var facebookLogoImageView: UIImageView = {
        let fbLogoImageView = UIImageView()
        fbLogoImageView.image = UIImage(named: "facebook_f")
        fbLogoImageView.contentMode = .scaleAspectFit
        fbLogoImageView.layer.cornerRadius = 44
        fbLogoImageView.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        fbLogoImageView.layer.borderWidth = 1
        fbLogoImageView.translatesAutoresizingMaskIntoConstraints = false
        fbLogoImageView.clipsToBounds = true
        fbLogoImageView.isUserInteractionEnabled = true
        return fbLogoImageView
    }()
    var emailTextField: UITextField = {
        let usernameTF = UITextField()
        usernameTF.placeholder = "EMAIL"
        usernameTF.textAlignment = .center
        usernameTF.layer.borderWidth = 1
        usernameTF.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        usernameTF.layer.cornerRadius = 10
        usernameTF.translatesAutoresizingMaskIntoConstraints = false
        usernameTF.autocapitalizationType = .none
        return usernameTF
    }()
    
    var passwordTextField: UITextField = {
        let passwordTF = UITextField()
        passwordTF.placeholder = "PASSWORD"
        passwordTF.textAlignment = .center
        passwordTF.layer.borderWidth = 1
        passwordTF.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        passwordTF.layer.cornerRadius = 10
        passwordTF.translatesAutoresizingMaskIntoConstraints = false
        passwordTF.autocapitalizationType = .none
        passwordTF.isSecureTextEntry = true
        return passwordTF
    }()
    
    var forgotPasswordLabel: UILabel = {
        let forgotLabel = UILabel()
        forgotLabel.text = "I forgot my password?"
        forgotLabel.font = UIFont(name: "Helvetica Neue", size: 20)
        forgotLabel.translatesAutoresizingMaskIntoConstraints = false
        forgotLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        forgotLabel.isUserInteractionEnabled = true
        return forgotLabel
    }()
    
    var loginButton: UIButton = {
        let loginButton = UIButton()
        loginButton.setTitle("Login", for: .normal)
        loginButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        loginButton.titleLabel?.textColor =  UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        loginButton.titleLabel?.textAlignment = .center
        loginButton.layer.borderWidth = 1
        loginButton.layer.cornerRadius = 10
        loginButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        loginButton.translatesAutoresizingMaskIntoConstraints = false
        return loginButton
    }()
    var seperator: UIView = {
        let seperator = UIView()
        seperator.backgroundColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        seperator.translatesAutoresizingMaskIntoConstraints = false
        return seperator
    }()
    var createAccountButton: UIButton = {
        let createAccountButton = UIButton()
        createAccountButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
, for: .normal)
        createAccountButton.setTitle("Create New Account", for: .normal)
        createAccountButton.titleLabel?.textAlignment = .center
        createAccountButton.layer.borderWidth = 1
        createAccountButton.layer.cornerRadius = 10
        createAccountButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        createAccountButton.translatesAutoresizingMaskIntoConstraints = false
        return createAccountButton
    }()
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    func setupViews() {
        self.view.addSubview(loginLabel)
        self.view.addSubview(logoImageView)
        self.view.addSubview(loginLabelFacebook)
        self.view.addSubview(loginLabelTwitter)
        self.view.addSubview(facebookLabel)
        self.view.addSubview(googleLabel)
        facebookLogoImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleFacebookLogin)))
        self.view.addSubview(facebookLogoImageView)
        googleLogoImageView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(googleImageViewHit)))
        self.view.addSubview(googleLogoImageView)
        self.view.addSubview(emailTextField)
        emailTextField.delegate = self
        self.view.addSubview(passwordTextField)
        passwordTextField.delegate = self
        forgotPasswordLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(gotoPasswordController)))
        self.view.addSubview(forgotPasswordLabel)
        loginButton.addTarget(self, action: #selector(login), for: .touchUpInside)
        self.view.addSubview(loginButton)
        self.view.addSubview(seperator)
        createAccountButton.addTarget(self, action: #selector(gotoRegisterController), for: .touchUpInside)
        self.view.addSubview(createAccountButton)
        
        loginLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 40).isActive = true
        loginLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        logoImageView.topAnchor.constraint(equalTo: loginLabel.bottomAnchor).isActive = true
        logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        logoImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        logoImageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        
        loginLabelTwitter.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 20).isActive = true
        loginLabelTwitter.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        
        loginLabelFacebook.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 20).isActive = true
        loginLabelFacebook.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        
        facebookLabel.topAnchor.constraint(equalTo: loginLabelFacebook.bottomAnchor).isActive = true
        facebookLabel.centerXAnchor.constraint(equalTo: loginLabelFacebook.centerXAnchor).isActive = true
        
        googleLabel.topAnchor.constraint(equalTo: loginLabelTwitter.bottomAnchor).isActive = true
        googleLabel.centerXAnchor.constraint(equalTo: loginLabelTwitter.centerXAnchor).isActive = true
        
        facebookLogoImageView.topAnchor.constraint(equalTo: logoImageView.bottomAnchor).isActive = true
        facebookLogoImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        facebookLogoImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        facebookLogoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: -50).isActive = true
        
        googleLogoImageView.topAnchor.constraint(equalTo: logoImageView.bottomAnchor).isActive = true
        googleLogoImageView.widthAnchor.constraint(equalToConstant: 100).isActive = true
        googleLogoImageView.heightAnchor.constraint(equalToConstant: 100).isActive = true
        googleLogoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor, constant: 50).isActive = true
        
        emailTextField.topAnchor.constraint(equalTo: facebookLogoImageView.bottomAnchor, constant: 30).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        emailTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        emailTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        emailTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        passwordTextField.topAnchor.constraint(equalTo: emailTextField.bottomAnchor, constant: 20).isActive = true
        passwordTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        passwordTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        passwordTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        passwordTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        forgotPasswordLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        forgotPasswordLabel.topAnchor.constraint(equalTo: passwordTextField.bottomAnchor, constant: 5).isActive = true
        
        loginButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        loginButton.topAnchor.constraint(equalTo: forgotPasswordLabel.bottomAnchor, constant: 30).isActive = true
        loginButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        loginButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        loginButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        seperator.topAnchor.constraint(equalTo: loginButton.bottomAnchor, constant: 50).isActive = true
        seperator.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        seperator.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        seperator.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        seperator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        createAccountButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        createAccountButton.topAnchor.constraint(equalTo: seperator.bottomAnchor, constant: 30).isActive = true
        createAccountButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        createAccountButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        createAccountButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
    }
    @objc func handleFacebookLogin() {
        FBSDKLoginManager().logIn(withReadPermissions: ["email","public_profile"], from: self)
        { (result, err) in
            if err != nil {
                print("FB Login failed: ", err!)
                return
            }
            self.gotoHomeScreen()
            self.showFacebookUserInfo()
        }
    }
    @objc func googleImageViewHit() {
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().signIn()
        
        if GIDSignIn.sharedInstance().hasAuthInKeychain() {
            self.gotoHomeScreen()
            
        }
    }
    func showFacebookUserInfo()  {
        let accessToken = FBSDKAccessToken.current()
        guard let accessTokenString = accessToken?.tokenString else {
            return
        }
        
        let credentials = FacebookAuthProvider.credential(withAccessToken: accessTokenString)
        
        
        Auth.auth().signInAndRetrieveData(with: credentials) { (user, error) in
            let UID = (user?.user.uid)!
            if error != nil {
                print("Firebase Auth failed: ", error!)
            }
            else
            {
                FBSDKGraphRequest(graphPath: "/me", parameters: ["fields": "id,name,email,picture.type(large),first_name, last_name"])?.start(completionHandler: { (connection, result, err) in
                if err != nil {
                    print("Failed to start graph result: ", err!)
                    return
                }
                
                if FBSDKAccessToken.current() != nil {
                    let data : Data!
                    data = UIImage.pngData(UIImage(named: "dummy")!)()
                    let storageRef = Storage.storage().reference().child("profile_images").child(UID)
                    
                    let dummyImagesRef = storageRef.child("dummy")
                    
                    // Upload the file to the path "images/rivers.jpg"
                    _ = dummyImagesRef.putData(data, metadata: nil) { (metadata, error) in
                        guard metadata != nil else {
                            // Uh-oh, an error occurred!
                            return
                        }
                        
                    }
                    let dictionary:[String:AnyObject] = result as! [String : AnyObject]
                    
                    let ref =  Database.database().reference(fromURL: "https://locnet.firebaseio.com")
                    
                    let userRef = ref.child("users").child(UID)
                    
                    let values = ["Full_Name": "\(dictionary["first_name"]!) \(dictionary["last_name"]!)", "User_Name": dictionary["name"]!, "Email": dictionary["email"]!] as [String : Any]
                    
                    userRef.updateChildValues(values, withCompletionBlock: { (error, ref) in
                        if error != nil {
                            print("Firbase updating failed: ", error!)
                        }
                        else {
                            print("User is signed in Facebook")
                            self.gotoHomeScreen()
                        }
                    })
                }
            })
            }
        }
        
        
    }
    @objc func gotoRegisterController() {
        let signUpVC = SignUpViewController()
        signUpVC.modalPresentationStyle = .custom
        signUpVC.modalTransitionStyle = .crossDissolve
        self.present(signUpVC, animated: true, completion: nil)
    }
    @objc func gotoHomeScreen() {
        let homeVC =  TransitionViewController()
        homeVC.modalPresentationStyle = .custom
        homeVC.modalTransitionStyle = .crossDissolve
        self.present(homeVC, animated: true, completion: nil)
        /**
        let homeVC = HomeViewController()
        homeVC.modalPresentationStyle = .custom
        homeVC.modalTransitionStyle = .crossDissolve
        let navEditorViewController: UINavigationController = UINavigationController(rootViewController: homeVC)
        self.present(navEditorViewController, animated: false, completion: nil)**/
        
    }
    
    @objc func gotoPasswordController() {
        let passwordVC =  PasswordResetViewController()
        passwordVC.modalPresentationStyle = .custom
        passwordVC.modalTransitionStyle = .crossDissolve
        self.present(passwordVC, animated: true, completion: nil)
    }
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "^(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?(?:(?:(?:[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+(?:\\.[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+)*)|(?:\"(?:(?:(?:(?: )*(?:(?:[!#-Z^-~]|\\[|\\])|(?:\\\\(?:\\t|[ -~]))))+(?: )*)|(?: )+)\"))(?:@)(?:(?:(?:[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)(?:\\.[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)*)|(?:\\[(?:(?:(?:(?:(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))\\.){3}(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))))|(?:(?:(?: )*[!-Z^-~])*(?: )*)|(?:[Vv][0-9A-Fa-f]+\\.[-A-Za-z0-9._~!$&'()*+,;=:]+))\\])))(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?$"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    
    @objc func login() {
        if emailTextField.text == "" || passwordTextField.text == "" {
            let alertController = UIAlertController(title: "Error", message: "You missed something!! ", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
            
        }
        else if isValidEmail(testStr: emailTextField.text!)  == false {
            let alertController = UIAlertController(title: "Error", message: "Please enter a valid email", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            Auth.auth().signIn(withEmail: emailTextField.text!, password: passwordTextField.text!) { (user, error) in
                if error != nil {
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: {
                        self.emailTextField.text = ""
                        self.passwordTextField.text = ""
                    })
                }
                else {
                    self.gotoHomeScreen()
                }
            }
        }
        
    }

}
