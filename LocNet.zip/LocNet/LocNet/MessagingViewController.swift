//
//  MessagingViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/27/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class MessagingViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.prefersLargeTitles = true
        self.title = "Messaging"
        // Do any additional setup after loading the view.
    }
    
    
}
