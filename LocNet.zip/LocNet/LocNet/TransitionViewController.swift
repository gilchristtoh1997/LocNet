//
//  TransitionViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/9/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class TransitionViewController: UIViewController{
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupView()
        
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        sleep(3)
        presentHome()
    }
    let loadingLabel: UILabel = {
        let loading = UILabel()
        loading.translatesAutoresizingMaskIntoConstraints = false
        loading.text = "Loading..."
        loading.font = UIFont.boldSystemFont(ofSize: 20)
        loading.textColor = UIColor.black
        loading.textAlignment = .center
        return loading
    }()
    var spinner: UIActivityIndicatorView = {
        let spinner = UIActivityIndicatorView(style: .gray)
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        return spinner
    }()
    
    func presentHome() {
        let root = RootViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        root.modalPresentationStyle = .custom
        root.modalTransitionStyle = .crossDissolve
        self.present(root, animated: true, completion: nil)
        
    }
    func setupView() {
        view.addSubview(loadingLabel)
        view.addSubview(spinner)
        loadingLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        loadingLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        loadingLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        
        spinner.topAnchor.constraint(equalTo: loadingLabel.bottomAnchor, constant: 10).isActive = true
        spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }

}
