//
//  ViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/22/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        setUpConstraints()
        
    }
    override func viewDidAppear(_ animated: Bool) {
        sleep(3)
        presentLogin()
    }
    var spinner: UIActivityIndicatorView = {
        let spinner = UIActivityIndicatorView(style: .whiteLarge)
        spinner.translatesAutoresizingMaskIntoConstraints = false
        spinner.startAnimating()
        return spinner
    }()

    var logoImageView: UIImageView = {
        let logoImageView = UIImageView()
        logoImageView.image = UIImage(named: "color_logo_with_background")
        logoImageView.contentMode = .scaleAspectFit
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.clipsToBounds = true
        return logoImageView
    }()
    func presentLogin() {
        let loginVC = LoginViewController() 
        loginVC.modalPresentationStyle = .formSheet
        loginVC.modalTransitionStyle = .crossDissolve
        self.present(loginVC, animated: true, completion: nil)
                
    }
    func setUpConstraints() {
        self.view.addSubview(logoImageView)
        self.view.addSubview(spinner)
        logoImageView.centerYAnchor.constraint(equalTo: view.centerYAnchor).isActive = true
        logoImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        logoImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        logoImageView.heightAnchor.constraint(equalToConstant: 150).isActive = true
        
        spinner.topAnchor.constraint(equalTo: logoImageView.bottomAnchor, constant: 10).isActive = true
        spinner.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true


    }


}

