//
//  SegmentedControlExt.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/30/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import Foundation
import UIKit

extension UISegmentedControl {
    func setAppearance() {
        self.backgroundColor = UIColor.clear
        self.tintColor = UIColor.clear
        
        self.setTitleTextAttributes([
            NSAttributedString.Key.font : UIFont(name: "DINCondensed-Bold", size: 18)!,
            NSAttributedString.Key.foregroundColor: UIColor.lightGray
            ], for: .normal)
        self.setTitleTextAttributes([
            NSAttributedString.Key.font : UIFont(name: "DINCondensed-Bold", size: 18)!,
            NSAttributedString.Key.foregroundColor: UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            ], for: .selected)
    }
}
