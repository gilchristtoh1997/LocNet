//
//  TabViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/27/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class TabViewController: UITabBarController, UITabBarControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.isTranslucent = false
        view.backgroundColor = UIColor.white
        self.delegate = self
        addTabs()
        navigationController?.navigationBar.prefersLargeTitles = true
        self.title = self.selectedViewController?.title
    }
    
    override func viewWillLayoutSubviews() {
        navigationController?.navigationBar.prefersLargeTitles = true
    }
    override func viewDidAppear(_ animated: Bool) {
        self.navigationController?.navigationBar.isTranslucent = false

    }
    func addTabs() {
        //let homeVC = HomeViewController()
        //homeVC.tabBarItem = UITabBarItem(title: "Home", image: UIImage(named: "home"), tag: 0)
        
        let connectionVC = ConnectionViewController()
        connectionVC.tabBarItem = UITabBarItem(title: "Connections", image: UIImage(named: "connection"), tag: 0)
        
        //let messagingVC = MessagingViewController()
        //messagingVC.tabBarItem = UITabBarItem(title: "Messaging", image: UIImage(named: "messaging"), tag: 2)
        
        let notificationVC = NotificationViewController()
        notificationVC.tabBarItem = UITabBarItem(title: "Notifications", image: UIImage(named: "notification"), tag: 1)
        
        let profileVC = ProfileViewController()
        profileVC.tabBarItem = UITabBarItem(title: "Profile", image: UIImage(named: "profile_icon"), tag: 4)
        
        let viewControllerList = [connectionVC, notificationVC, profileVC]
        viewControllers = viewControllerList
    }
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        self.title = viewController.title
        if viewController.title == "Profile" {
            let settingsButton = UIBarButtonItem(title: "Settings", style: .plain, target: self, action: #selector(handleSettings))
            settingsButton.setTitleTextAttributes([NSAttributedString.Key.foregroundColor: UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)], for: .normal)
            self.navigationItem.rightBarButtonItem = settingsButton
        }
        else {
            self.navigationItem.rightBarButtonItem = nil
        }
    }
    @objc func handleSettings() {
        let settingsVC = SettingsViewController()
        //settingsVC.modalPresentationStyle = .custom
        //settingsVC.modalTransitionStyle = .crossDissolve
        //self.navigationController?.navigationBar.isTranslucent = false; 
        self.navigationController?.pushViewController(settingsVC, animated: true)
    }

    
}
