//
//  ConnectionViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/27/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class ConnectionViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        // Do any additional setup after loading the view.
    }
    var navBar: UINavigationBar = {
        let navBar = UINavigationBar()
        navBar.translatesAutoresizingMaskIntoConstraints = false
        navBar.backgroundColor = UIColor.clear
        navBar.isTranslucent = false
        return navBar
    }()
    
    var titleImageView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "locnet")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.clipsToBounds = true
        return imgView
    }()
    var rightImageView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "messaging")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.clipsToBounds = true
        return imgView
    }()
    
    func setupViews() {
        view.addSubview(navBar)
        navBar.addSubview(titleImageView)
        navBar.addSubview(rightImageView)
        
        navBar.setBackgroundImage(UIImage(named: ""), for: .default)
        navBar.shadowImage = UIImage()
        
        navBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        navBar.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        navBar.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        navBar.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        rightImageView.topAnchor.constraint(equalTo: navBar.topAnchor).isActive = true
        rightImageView.centerXAnchor.constraint(equalTo: navBar.centerXAnchor).isActive = true
        rightImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        rightImageView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        titleImageView.topAnchor.constraint(equalTo: navBar.topAnchor).isActive = true
        titleImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        titleImageView.centerYAnchor.constraint(equalTo: navBar.centerYAnchor).isActive = true
        titleImageView.widthAnchor.constraint(equalToConstant: 80).isActive = true
        titleImageView.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }

    

}
