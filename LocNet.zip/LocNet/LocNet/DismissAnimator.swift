//
//  DismissAnimator.swift
//  LocNet
//
//  Created by Gilchrist Toh on 5/26/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//


import UIKit

class DismissAnimator : NSObject {
    
    
}

extension DismissAnimator : UIViewControllerAnimatedTransitioning {
    func transitionDuration(using transitionContext: UIViewControllerContextTransitioning?) -> TimeInterval {
        return 0.6
    }
    
    func animateTransition(using transitionContext: UIViewControllerContextTransitioning) {
        
    }
}
