//
//  swipeSegue.swift
//  LocNet
//
//  Created by Gilchrist Toh on 4/19/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class swipeSegue: UIStoryboardSegue {
    override func perform() {
        
    }
    
    
}
