//
//  ProfileViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/27/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController, UITableViewDelegate , UITableViewDataSource, UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    let blackView = UIView()

    var underlineBarLeftAnchor: NSLayoutConstraint!
    var setBgPic: Bool = false
    var setProfilePic: Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        navigationController?.navigationBar.prefersLargeTitles = true
        self.title = "Profile"
        setupViews()
        myTableView.register(postTableViewCell.self, forCellReuseIdentifier: "post")
        myTableView.register(photoTableViewCell.self, forCellReuseIdentifier: "photo")
        myTableView.contentInset = UIEdgeInsets.zero
        myTableView.estimatedRowHeight = 230
        myTableView.rowHeight = UITableView.automaticDimension
        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        myTableView.tableHeaderView = headerView
        myTableView.estimatedRowHeight = 230
        myTableView.rowHeight = UITableView.automaticDimension
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        sizeHeaderToFit()
    }
    override func viewDidAppear(_ animated: Bool) {
        self.myTableView.reloadData()
    }
    var backgroundProfileImage : UIImageView = {
        let bgImageView = UIImageView()
        bgImageView.backgroundColor = UIColor.white
        bgImageView.image = UIImage(named: "dummy")
        bgImageView.contentMode = .scaleAspectFit
        bgImageView.translatesAutoresizingMaskIntoConstraints = false
        bgImageView.isUserInteractionEnabled = true
        bgImageView.clipsToBounds = true
        bgImageView.layer.masksToBounds = true
        return bgImageView
    }()
    var profileImage: UIImageView = {
        let profileImageView = UIImageView()
        profileImageView.backgroundColor = UIColor.white
        profileImageView.image = UIImage(named: "dummy")
        profileImageView.contentMode = .scaleAspectFit
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 44
        profileImageView.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        profileImageView.layer.borderWidth = 1
        profileImageView.isUserInteractionEnabled = true
        profileImageView.layer.masksToBounds = true
        return profileImageView
    }()
    
    var segmentedControl: UISegmentedControl = {
        let items = ["Posts","Photos"]
        let sgControl = UISegmentedControl(items: items)
        sgControl.translatesAutoresizingMaskIntoConstraints = false
        sgControl.selectedSegmentIndex = 0
        return sgControl
    }()
    
    var buttonBar : UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    var seperator: UIView = {
        let seperator = UIView()
        seperator.backgroundColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        seperator.translatesAutoresizingMaskIntoConstraints = false
        return seperator
    }()
    var uiviewSeperator: UIView = {
        let seperator = UIView()
        seperator.backgroundColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        seperator.translatesAutoresizingMaskIntoConstraints = false
        return seperator
    }()
    
    var myTableView: UITableView = {
        let tableView = UITableView()
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.backgroundColor = UIColor.white
        return tableView
    }()
    
    var headerView: UIView = {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.white
        return headerView
    }()

    func sizeHeaderToFit() {
        let headerView = myTableView.tableHeaderView!
        
        headerView.setNeedsLayout()
        headerView.layoutIfNeeded()
        
        let height = headerView.systemLayoutSizeFitting(UIView.layoutFittingCompressedSize).height
        var frame = headerView.frame
        frame.size.height = height
        headerView.frame = frame
        myTableView.tableHeaderView = headerView
    }
    
    func setupViews() {
        myTableView.delegate = self
        myTableView.dataSource = self
        self.view.addSubview(myTableView)
        myTableView.contentInset = UIEdgeInsets(top: 1.0, left: 0.0, bottom: 0.0, right: 0.0)
        myTableView.isScrollEnabled = true
        myTableView.topAnchor.constraint(equalTo: view.topAnchor).isActive = true
        myTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        myTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        myTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor).isActive = true
        
        
        headerView.addSubview(buttonBar)
        headerView.addSubview(backgroundProfileImage)
        backgroundProfileImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleBgImage)))
        backgroundProfileImage.topAnchor.constraint(equalTo: headerView.topAnchor).isActive = true
        backgroundProfileImage.leadingAnchor.constraint(equalTo: headerView.leadingAnchor).isActive = true
        backgroundProfileImage.trailingAnchor.constraint(equalTo: headerView.trailingAnchor).isActive = true
        backgroundProfileImage.widthAnchor.constraint(equalTo: headerView.widthAnchor).isActive = true
        backgroundProfileImage.heightAnchor.constraint(equalToConstant: 250).isActive = true
        
        headerView.addSubview(profileImage)
        profileImage.topAnchor.constraint(equalTo: backgroundProfileImage.bottomAnchor, constant: -50).isActive = true
        profileImage.centerXAnchor.constraint(equalTo: backgroundProfileImage.centerXAnchor).isActive = true
        profileImage.widthAnchor.constraint(equalToConstant: 100).isActive = true
        profileImage.heightAnchor.constraint(equalToConstant: 100).isActive = true
        profileImage.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(handleProfileImage)))
        
        headerView.addSubview(segmentedControl)
        segmentedControl.setAppearance()
        segmentedControl.addTarget(self, action: #selector(segmentedControlValueChanged), for: .valueChanged)
        segmentedControl.topAnchor.constraint(equalTo: profileImage.bottomAnchor, constant: 30).isActive = true
        segmentedControl.leadingAnchor.constraint(equalTo: headerView.leadingAnchor).isActive = true
        segmentedControl.trailingAnchor.constraint(equalTo: headerView.trailingAnchor).isActive = true
        segmentedControl.widthAnchor.constraint(equalTo: headerView.widthAnchor).isActive = true
        segmentedControl.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        headerView.addSubview(seperator)
        seperator.topAnchor.constraint(equalTo: segmentedControl.topAnchor).isActive = true
        seperator.widthAnchor.constraint(equalTo: headerView.widthAnchor).isActive = true
        seperator.leadingAnchor.constraint(equalTo: headerView.leadingAnchor).isActive = true
        seperator.trailingAnchor.constraint(equalTo: headerView.trailingAnchor).isActive = true
        seperator.heightAnchor.constraint(equalToConstant: 1).isActive = true
        
        buttonBar.topAnchor.constraint(equalTo: segmentedControl.bottomAnchor).isActive = true
        buttonBar.heightAnchor.constraint(equalToConstant: 5).isActive = true
        buttonBar.widthAnchor.constraint(equalTo: segmentedControl.widthAnchor, multiplier: 1 / CGFloat(segmentedControl.numberOfSegments)).isActive = true
        
        underlineBarLeftAnchor = buttonBar.leftAnchor.constraint(equalTo: segmentedControl.leftAnchor, constant: 0)
        underlineBarLeftAnchor.isActive = true
        
        headerView.addSubview(uiviewSeperator)
        headerView.bottomAnchor.constraint(equalTo: buttonBar.bottomAnchor).isActive = true
        uiviewSeperator.topAnchor.constraint(equalTo: buttonBar.bottomAnchor).isActive = true
        uiviewSeperator.widthAnchor.constraint(equalTo: headerView.widthAnchor).isActive = true
        uiviewSeperator.leadingAnchor.constraint(equalTo: headerView.leadingAnchor).isActive = true
        uiviewSeperator.trailingAnchor.constraint(equalTo: headerView.trailingAnchor).isActive = true
        uiviewSeperator.heightAnchor.constraint(equalToConstant: 1).isActive = true
    }
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        if setProfilePic == true {
            profileImage.contentMode = .scaleAspectFit
            profileImage.image = pickedImage
        }
        else if setBgPic == true {
            backgroundProfileImage.contentMode = .scaleAspectFit
            backgroundProfileImage.image = pickedImage
        }
        else {
            return
        }
        setProfilePic = false
        setBgPic = false
        self.dismiss(animated: true, completion: nil)

        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
    @objc func handleBgImage() {
        print("In background image handle")
        setBgPic = true
        let imgPickerController = UIImagePickerController()
        imgPickerController.delegate = self
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imgPickerController.sourceType = .camera
                self.present(imgPickerController, animated: true, completion: nil)
            }else {
                print("Camera not activated")
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imgPickerController.sourceType = .photoLibrary
            self.present(imgPickerController, animated: true, completion: nil)
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }
    
    @objc func handleOptions() {

        let actionSheet = UIAlertController(title: "Options", message: nil, preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Mute User", style: .default, handler: { (action: UIAlertAction) in
            
        }))
        actionSheet.addAction(UIAlertAction(title: "Unfollow User", style: .default, handler: { (action: UIAlertAction) in
            
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
        
        
    }
    @objc func dismissBlackView()
    {
        UIView.animate(withDuration: 0.5){
            self.blackView.alpha = 0
        }
        
    }
    @objc func handleProfileImage() {
        print("In profile Image handle")
        setProfilePic = true
        let imgPickerController = UIImagePickerController()
        imgPickerController.delegate = self
        let actionSheet = UIAlertController(title: "Photo Source", message: "Choose a source", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Camera", style: .default, handler: { (action: UIAlertAction) in
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                imgPickerController.sourceType = .camera
                self.present(imgPickerController, animated: true, completion: nil)
            }else {
                print("Camera not activated")
            }
        }))
        actionSheet.addAction(UIAlertAction(title: "Photo Library", style: .default, handler: { (action: UIAlertAction) in
            imgPickerController.sourceType = .photoLibrary
            self.present(imgPickerController, animated: true, completion: nil)
        }))
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        self.present(actionSheet, animated: true, completion: nil)
    }
    @objc func segmentedControlValueChanged() {
        let getIndex = self.segmentedControl.selectedSegmentIndex
        let padding = buttonBar.frame.width * CGFloat(self.segmentedControl.selectedSegmentIndex)
        underlineBarLeftAnchor.constant = padding
        
        UIView.animate(withDuration: 0.3) {
            self.view.layoutIfNeeded()
        }
        switch (getIndex) {
        case 0:
            print("O selected")
            myTableView.reloadSections(NSIndexSet(index: 0) as IndexSet, with: .none)
            break
        case 1:
            myTableView.reloadSections(NSIndexSet(index: 0) as IndexSet, with: .none)
            print("1 selected")
            break
        default:
            print("Nothing selected")
        }
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        myTableView.estimatedRowHeight = 230
        myTableView.rowHeight = UITableView.automaticDimension
        return 9
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        myTableView.estimatedRowHeight = 230
        myTableView.rowHeight = UITableView.automaticDimension
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    @objc func handleShare() {
        let activityVC = UIActivityViewController(activityItems: ["www.google.com"], applicationActivities: nil)
        activityVC.popoverPresentationController?.sourceView = self.view
        self.present(activityVC, animated: true, completion: nil)
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1 = tableView.dequeueReusableCell(withIdentifier: "post", for: indexPath) as! postTableViewCell
        let cell2 = tableView.dequeueReusableCell(withIdentifier: "photo", for: indexPath) as! photoTableViewCell
        
        let getIndex = self.segmentedControl.selectedSegmentIndex
        switch getIndex {
        case 0:
            cell1.selectionStyle = .none
            cell1.separatorInset = .zero
            cell1.optionButton.addTarget(self, action: #selector(handleOptions), for: .touchUpInside)
            cell1.shareButton.addTarget(self, action: #selector(handleShare), for: .touchUpInside)
        case 1:

            cell2.selectionStyle = .none
            cell2.separatorInset = .zero
            cell2.optionButton.addTarget(self, action: #selector(handleOptions), for: .touchUpInside)
            cell2.shareButton.addTarget(self, action: #selector(handleShare), for: .touchUpInside)

            return cell2
        default:
            break
        }
        return cell1
    }
    
}
class postTableViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    let postLabel: UILabel = {
        let post = UILabel()
        post.translatesAutoresizingMaskIntoConstraints = false
        post.numberOfLines = 0
        post.lineBreakMode = .byWordWrapping
        post.text = "It's raining today and i like to go outside and play basketball with my friends from home. But you know something? I dont even know if i'll play basketball tomorrow. I played basketball today and I sweated and sweated the shit out of my shit today. It felt so good and I wanna do it again but i have plenty of work to do. I know it's not the best or the thing I want to do right now but that all i want to do fr fr. "
        post.textColor = UIColor.black
        post.sizeToFit()
        return post
    }()
    let photo: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "music_guy")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.layer.borderWidth = 1
        imgView.layer.borderColor = UIColor.black.cgColor
        imgView.layer.cornerRadius = 30
        imgView.isUserInteractionEnabled = true
        imgView.clipsToBounds = true
        return imgView
    }()
    let profileName: UILabel = {
        let profileName = UILabel()
        profileName.translatesAutoresizingMaskIntoConstraints = false
        profileName.text = "Gilchrist Toh"
        profileName.font = UIFont.boldSystemFont(ofSize: 20)
        profileName.textColor = UIColor.black
        return profileName
    }()
    
    let commentButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "comment"), for: .normal)
        //button.setTitle("Com", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let likeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "like"), for: .normal)
        //button.setTitle("Like", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let shareButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "share"), for: .normal)
        //button.setTitle("share", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let optionButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "more"), for: .normal)
        //button.setTitle("share", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let username: UILabel = {
        let username = UILabel()
        username.translatesAutoresizingMaskIntoConstraints = false
        username.text = "@gilchriston50"
        username.textColor = UIColor.lightGray
        return username
    }()
    let numLikes: UILabel = {
        let likes = UILabel()
        likes.translatesAutoresizingMaskIntoConstraints = false
        likes.text = "50"
        likes.textColor = UIColor.black
        return likes
    }()
    
    let numComments: UILabel = {
        let comments = UILabel()
        comments.translatesAutoresizingMaskIntoConstraints = false
        comments.text = "10"
        comments.textColor = UIColor.black
        return comments
    }()
    
    func setupViews() {
        self.addSubview(postLabel)
        self.addSubview(photo)
        self.addSubview(profileName)
        self.addSubview(username)
        self.addSubview(commentButton)
        self.addSubview(shareButton)
        self.addSubview(likeButton)
        self.addSubview(optionButton)
        self.addSubview(numLikes)
        self.addSubview(numComments)
        
        photo.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        photo.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20).isActive = true
        photo.widthAnchor.constraint(equalToConstant: 60).isActive = true
        photo.heightAnchor.constraint(equalToConstant: 60).isActive = true
        photo.bottomAnchor.constraint(equalTo: postLabel.topAnchor, constant: -10).isActive = true
        
        profileName.topAnchor.constraint(equalTo: self.topAnchor, constant: 15).isActive = true
        profileName.leadingAnchor.constraint(equalTo: photo.trailingAnchor, constant: 10).isActive = true
        profileName.bottomAnchor.constraint(equalTo: username.topAnchor, constant: -5).isActive = true
        
        username.topAnchor.constraint(equalTo: profileName.bottomAnchor, constant: -5).isActive = true
        username.leadingAnchor.constraint(equalTo: photo.trailingAnchor, constant: 10).isActive = true
        username.bottomAnchor.constraint(equalTo: postLabel.topAnchor, constant: -20).isActive = true
        
        postLabel.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 20).isActive = true
        postLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20).isActive = true
        postLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        postLabel.bottomAnchor.constraint(equalTo: commentButton.topAnchor, constant: -10).isActive = true
        
        commentButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        commentButton.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 50).isActive = true
        commentButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        commentButton.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
        //commentButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        likeButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        likeButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        shareButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        likeButton.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
        //shareButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        shareButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        shareButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -50).isActive = true
        commentButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        shareButton.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
        //commentButton.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        optionButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        optionButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        optionButton.bottomAnchor.constraint(equalTo: profileName.bottomAnchor).isActive = true
        
        numComments.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        numComments.leadingAnchor.constraint(equalTo: commentButton.trailingAnchor, constant: 5).isActive = true
        numComments.trailingAnchor.constraint(equalTo: likeButton.leadingAnchor).isActive = true
        numComments.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
        
        numLikes.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        numLikes.leadingAnchor.constraint(equalTo: likeButton.trailingAnchor, constant: 5).isActive = true
        numLikes.trailingAnchor.constraint(equalTo: shareButton.leadingAnchor).isActive = true
        numLikes.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
    }
}

class photoTableViewCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setupViews()
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    let profileName: UILabel = {
        let profileName = UILabel()
        profileName.translatesAutoresizingMaskIntoConstraints = false
        profileName.text = "Gilchrist Toh"
        profileName.font = UIFont.boldSystemFont(ofSize: 20)
        profileName.textColor = UIColor.black
        return profileName
    }()
    let username: UILabel = {
        let username = UILabel()
        username.translatesAutoresizingMaskIntoConstraints = false
        username.text = "@gilchriston50"
        username.textColor = UIColor.lightGray
        return username
    }()
    let postLabel: UILabel = {
        let post = UILabel()
        post.translatesAutoresizingMaskIntoConstraints = false
        post.numberOfLines = 0
        post.lineBreakMode = .byWordWrapping
        post.text = "It's raining today and i like to go outside and play basketball with my friends from home. But you know something? I dont even know if i'll play basketball tomorrow."
        post.textColor = UIColor.black
        post.sizeToFit()
        return post
    }()
    let profileImage: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "music_guy")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.layer.borderWidth = 1
        imgView.layer.borderColor = UIColor.black.cgColor
        imgView.layer.cornerRadius = 30
        imgView.isUserInteractionEnabled = true
        imgView.clipsToBounds = true
        return imgView
    }()
    let photo: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "locnet")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.layer.borderWidth = 1
        imgView.layer.borderColor = UIColor.black.cgColor
        imgView.layer.cornerRadius = 12
        imgView.isUserInteractionEnabled = true
        imgView.clipsToBounds = true
        return imgView
    }()
    let numLikes: UILabel = {
        let likes = UILabel()
        likes.translatesAutoresizingMaskIntoConstraints = false
        likes.text = "50"
        likes.textColor = UIColor.black
        return likes
    }()
    
    let numComments: UILabel = {
        let comments = UILabel()
        comments.translatesAutoresizingMaskIntoConstraints = false
        comments.text = "10"
        comments.textColor = UIColor.black
        return comments
    }()
    let commentButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "comment"), for: .normal)
        //button.setTitle("Com", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let likeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "like"), for: .normal)
        //button.setTitle("Like", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let shareButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "share"), for: .normal)
        //button.setTitle("share", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    let optionButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "more"), for: .normal)
        //button.setTitle("share", for: .normal)
        button.setTitleColor(UIColor.black, for: .normal)
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    func setupViews() {
        self.addSubview(profileImage)
        self.addSubview(profileName)
        self.addSubview(username)
        self.addSubview(optionButton)
        self.addSubview(postLabel)
        self.addSubview(photo)
        self.addSubview(commentButton)
        self.addSubview(numComments)
        self.addSubview(likeButton)
        self.addSubview(numLikes)
        self.addSubview(shareButton)
        
        profileImage.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        profileImage.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20).isActive = true
        profileImage.widthAnchor.constraint(equalToConstant: 60).isActive = true
        profileImage.heightAnchor.constraint(equalToConstant: 60).isActive = true
        profileImage.bottomAnchor.constraint(equalTo: postLabel.topAnchor, constant: -10).isActive = true
        
        profileName.topAnchor.constraint(equalTo: self.topAnchor, constant: 15).isActive = true
        profileName.leadingAnchor.constraint(equalTo: profileImage.trailingAnchor, constant: 10).isActive = true
        profileName.bottomAnchor.constraint(equalTo: username.topAnchor, constant: -5).isActive = true
        
        username.topAnchor.constraint(equalTo: profileName.bottomAnchor, constant: -5).isActive = true
        username.leadingAnchor.constraint(equalTo: profileImage.trailingAnchor, constant: 10).isActive = true
        username.bottomAnchor.constraint(equalTo: postLabel.topAnchor, constant: -20).isActive = true
        
        optionButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        optionButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        optionButton.bottomAnchor.constraint(equalTo: profileName.bottomAnchor).isActive = true
        
        photo.topAnchor.constraint(equalTo: postLabel.bottomAnchor, constant: 10).isActive = true
        photo.widthAnchor.constraint(equalToConstant: 150).isActive = true
        photo.heightAnchor.constraint(equalToConstant: 150).isActive = true
        photo.bottomAnchor.constraint(equalTo: commentButton.topAnchor, constant: -10).isActive = true
        photo.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        photo.centerYAnchor.constraint(equalTo: self.centerYAnchor, constant: 40).isActive = true
        
        postLabel.topAnchor.constraint(equalTo: profileImage.bottomAnchor, constant: 20).isActive = true
        postLabel.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 20).isActive = true
        postLabel.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        postLabel.bottomAnchor.constraint(equalTo: photo.topAnchor, constant: -10).isActive = true
        
        commentButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        commentButton.leadingAnchor.constraint(equalTo: self.leadingAnchor, constant: 50).isActive = true
        commentButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        commentButton.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10).isActive = true
        
        likeButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        likeButton.centerXAnchor.constraint(equalTo: self.centerXAnchor).isActive = true
        shareButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        likeButton.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10).isActive = true
        
        shareButton.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        shareButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -50).isActive = true
        commentButton.widthAnchor.constraint(equalToConstant: 20).isActive = true
        shareButton.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10).isActive = true
        
        optionButton.topAnchor.constraint(equalTo: self.topAnchor, constant: 10).isActive = true
        optionButton.trailingAnchor.constraint(equalTo: self.trailingAnchor, constant: -20).isActive = true
        optionButton.bottomAnchor.constraint(equalTo: profileName.bottomAnchor).isActive = true
        
        numComments.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        numComments.leadingAnchor.constraint(equalTo: commentButton.trailingAnchor, constant: 5).isActive = true
        numComments.trailingAnchor.constraint(equalTo: likeButton.leadingAnchor).isActive = true
        numComments.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10).isActive = true
        
        numLikes.bottomAnchor.constraint(equalTo: self.bottomAnchor, constant: -10).isActive = true
        numLikes.leadingAnchor.constraint(equalTo: likeButton.trailingAnchor, constant: 5).isActive = true
        numLikes.trailingAnchor.constraint(equalTo: shareButton.leadingAnchor).isActive = true
        numLikes.topAnchor.constraint(equalTo: photo.bottomAnchor, constant: 10).isActive = true
    }
}
