//
//  TransitionCoordinator.swift
//  LocNet
//
//  Created by Gilchrist Toh on 4/19/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class TransitionCoordinator: NSObject, UINavigationControllerDelegate  {
    
    func navigationController(_ navigationController: UINavigationController,
                              animationControllerFor operation: UINavigationController.Operation,
                              from fromVC: UIViewController,
                              to toVC: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return CirculationTransition()
    }

}
