//
//  ContactUs.swift
//  LocNet
//
//  Created by Gilchrist Toh on 6/13/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class ContactUs: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        self.title = "Contact Us"
        setupViews()
    }
    override func viewWillDisappear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true
    }
    var textViewLabel: UILabel = {
        let textLabel = UILabel()
        textLabel.text = "Type your message below *"
        textLabel.textColor = UIColor.red
        textLabel.translatesAutoresizingMaskIntoConstraints = false
        return textLabel
    }()
    var emailTextBox: UITextView = {
        let textview = UITextView()
        textview.backgroundColor = UIColor.white
        textview.layer.cornerRadius = 12
        textview.layer.borderColor = UIColor.black.cgColor
        textview.layer.borderWidth = 1
        textview.translatesAutoresizingMaskIntoConstraints = false
        textview.font = UIFont(name: "Times New Roman", size: 18)
        return textview
    }()
    var submitButton: UIButton = {
        let button = UIButton()
        button.backgroundColor = UIColor.white
        button.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        button.setTitle("Submit", for: .normal)
        button.titleLabel?.textAlignment = .center
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 12
        button.layer.borderColor = UIColor.black.cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    func setupViews() {
        view.addSubview(textViewLabel)
        view.addSubview(emailTextBox)
        view.addSubview(submitButton)
        
        textViewLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 150).isActive = true
        textViewLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10).isActive = true
        
        emailTextBox.topAnchor.constraint(equalTo: textViewLabel.bottomAnchor, constant: 5).isActive = true
        emailTextBox.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 10).isActive = true
        emailTextBox.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10).isActive = true
        emailTextBox.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -20).isActive = true
        emailTextBox.heightAnchor.constraint(equalToConstant: 400).isActive = true
        
        submitButton.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -50).isActive = true
        submitButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40).isActive = true
        submitButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40).isActive = true
        submitButton.widthAnchor.constraint(equalToConstant: 60).isActive = true
        submitButton.heightAnchor.constraint(equalToConstant: 60).isActive = true
    }
    
}
