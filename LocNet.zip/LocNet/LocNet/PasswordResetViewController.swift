//
//  PasswordResetViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/26/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit
import Firebase

class PasswordResetViewController: UIViewController, UITextFieldDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setUpViews()
        // Do any additional setup after loading the view.
    }
    
    var keyImageView: UIImageView = {
        let keyImageView = UIImageView()
        keyImageView.image = UIImage(named: "key")
        keyImageView.contentMode = .scaleAspectFit
        keyImageView.translatesAutoresizingMaskIntoConstraints = false
        keyImageView.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        keyImageView.layer.borderWidth = 1
        keyImageView.layer.cornerRadius = 40
        keyImageView.clipsToBounds = true
        return keyImageView
    }()
    
    var troubleLoginLabel: UILabel = {
        let troubleLabel = UILabel()
        troubleLabel.text = "TROUBLE LOGGING IN?"
        troubleLabel.font = UIFont(name: "Helvetica Neue", size: 30)
        troubleLabel.translatesAutoresizingMaskIntoConstraints = false
        troubleLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        troubleLabel.isUserInteractionEnabled = true
        return troubleLabel
    }()
    
    var whatToDoLabel: UILabel = {
        let whatToDo = UILabel()
        whatToDo.numberOfLines = 3
        whatToDo.text = "Enter your email and\n we'll send you a link to get\n into your account."
        whatToDo.textAlignment = .center
        whatToDo.font = UIFont(name: "Helvetica Neue", size: 20)
        whatToDo.translatesAutoresizingMaskIntoConstraints = false
        whatToDo.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        whatToDo.isUserInteractionEnabled = true
        return whatToDo
    }()
    
    var emailTextField: UITextField = {
        let emailTF = UITextField()
        emailTF.placeholder = "Email"
        emailTF.textAlignment = .center
        emailTF.layer.borderWidth = 1
        emailTF.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        emailTF.layer.cornerRadius = 10
        emailTF.translatesAutoresizingMaskIntoConstraints = false
        emailTF.autocapitalizationType = .none
        return emailTF
    }()

    var sendLinkButton: UIButton = {
        let sendLinkButton = UIButton()
        sendLinkButton.setTitle("Send Link", for: .normal)
        sendLinkButton.setTitleColor(UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
            , for: .normal)
        sendLinkButton.titleLabel?.textColor =  UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        sendLinkButton.titleLabel?.textAlignment = .center
        sendLinkButton.layer.borderWidth = 1
        sendLinkButton.layer.cornerRadius = 10
        sendLinkButton.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        sendLinkButton.translatesAutoresizingMaskIntoConstraints = false
        return sendLinkButton
    }()
    
    var gotoSignUpLabel: UILabel = {
        let signUp = UILabel()
        signUp.text = "Not a Member? SignUp"
        signUp.font = UIFont(name: "Helvetica Neue", size: 20)
        signUp.translatesAutoresizingMaskIntoConstraints = false
        signUp.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        signUp.isUserInteractionEnabled = true
        return signUp
    }()
    
    func isValidEmail(testStr:String) -> Bool {
        let emailRegEx = "^(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?(?:(?:(?:[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+(?:\\.[-A-Za-z0-9!#$%&’*+/=?^_'{|}~]+)*)|(?:\"(?:(?:(?:(?: )*(?:(?:[!#-Z^-~]|\\[|\\])|(?:\\\\(?:\\t|[ -~]))))+(?: )*)|(?: )+)\"))(?:@)(?:(?:(?:[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)(?:\\.[A-Za-z0-9](?:[-A-Za-z0-9]{0,61}[A-Za-z0-9])?)*)|(?:\\[(?:(?:(?:(?:(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))\\.){3}(?:[0-9]|(?:[1-9][0-9])|(?:1[0-9][0-9])|(?:2[0-4][0-9])|(?:25[0-5]))))|(?:(?:(?: )*[!-Z^-~])*(?: )*)|(?:[Vv][0-9A-Fa-f]+\\.[-A-Za-z0-9._~!$&'()*+,;=:]+))\\])))(?:(?:(?:(?: )*(?:(?:(?:\\t| )*\\r\\n)?(?:\\t| )+))+(?: )*)|(?: )+)?$"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        let result = emailTest.evaluate(with: testStr)
        return result
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return false
    }
    
    func setUpViews() {
        self.view.addSubview(keyImageView)
        self.view.addSubview(troubleLoginLabel)
        self.view.addSubview(whatToDoLabel)
        self.view.addSubview(emailTextField)
        emailTextField.delegate = self
        sendLinkButton.addTarget(self, action: #selector(resetPassword), for: .touchUpInside)
        self.view.addSubview(sendLinkButton)
        gotoSignUpLabel.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(gotoSignUp)))
        self.view.addSubview(gotoSignUpLabel)
        
        keyImageView.topAnchor.constraint(equalTo: view.topAnchor, constant: 100).isActive = true
        keyImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        keyImageView.heightAnchor.constraint(equalToConstant: 80).isActive = true
        keyImageView.widthAnchor.constraint(equalToConstant: 80).isActive = true
        
        troubleLoginLabel.topAnchor.constraint(equalTo: keyImageView.bottomAnchor, constant: 20).isActive = true
        troubleLoginLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        whatToDoLabel.topAnchor.constraint(equalTo: troubleLoginLabel.bottomAnchor, constant: 10).isActive = true
        whatToDoLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        emailTextField.topAnchor.constraint(equalTo: whatToDoLabel.bottomAnchor, constant: 40).isActive = true
        emailTextField.heightAnchor.constraint(equalToConstant: 50).isActive = true
        emailTextField.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        emailTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        emailTextField.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true

        
        sendLinkButton.heightAnchor.constraint(equalToConstant: 50).isActive = true
        sendLinkButton.topAnchor.constraint(equalTo: gotoSignUpLabel.topAnchor, constant: -70).isActive = true
        sendLinkButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        sendLinkButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20).isActive = true
        sendLinkButton.widthAnchor.constraint(equalTo: view.widthAnchor, constant: -40).isActive = true
        
        gotoSignUpLabel.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -30).isActive = true
        gotoSignUpLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
    }
    
    @objc func gotoSignUp() {
        let signUpVC = SignUpViewController()
        signUpVC.modalPresentationStyle = .custom
        signUpVC.modalTransitionStyle = .crossDissolve
        self.present(signUpVC, animated: true, completion: nil)
    }
    @objc func gotoLogin() {
        let loginVC = LoginViewController()
        loginVC.modalPresentationStyle = .custom
        loginVC.modalTransitionStyle = .crossDissolve
        self.present(loginVC, animated: true, completion: nil)
    }
    
    @objc func resetPassword() {
        if emailTextField.text == "" {
            let alertController = UIAlertController(title: "Error", message: "Empty is empty!! ", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            present(alertController, animated: true, completion: nil)
            
        }
        else if isValidEmail(testStr: emailTextField.text!)  == false {
            let alertController = UIAlertController(title: "Error", message: "Please enter a valid email", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
        else
        {
            Auth.auth().sendPasswordReset(withEmail: emailTextField.text!) { (error) in
                var title = ""
                var message = ""
                
                if error != nil {
                    title = "Error!"
                    message = (error?.localizedDescription)!
                    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: { (true) in
                        self.emailTextField.text = ""
                    })
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
                else
                {
                    title = "Success!"
                    message = "Password reset email sent."
                    let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: { (true) in
                        self.emailTextField.text = ""
                        self.gotoLogin()
                    })
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                    
                }
            }
        }
    }
}
