//
//  HomeViewController.swift
//  LocNet
//
//  Created by Gilchrist Toh on 12/27/18.
//  Copyright © 2018 Gilchrist Toh. All rights reserved.
//

import UIKit


class HomeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        setupViews()
        let leftSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture(_:)))
        leftSwipe.direction = .left
        
        let rightSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture(_:)))
        rightSwipe.direction = .right
        
        let upSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture(_:)))
        upSwipe.direction = .up
        
        let downSwipe = UISwipeGestureRecognizer(target: self, action: #selector(handleGesture(_:)))
        downSwipe.direction = .down
        // Do any additional setup after loading the view.
        
        view.addGestureRecognizer(leftSwipe)
        view.addGestureRecognizer(rightSwipe)
        view.addGestureRecognizer(upSwipe)
        view.addGestureRecognizer(downSwipe)
    }


    var navBar: UINavigationBar = {
        let navBar = UINavigationBar()
        navBar.translatesAutoresizingMaskIntoConstraints = false
        navBar.backgroundColor = UIColor.clear
        navBar.isTranslucent = false
        return navBar
    }()
    
    var titleImageView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "locnet")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.clipsToBounds = true
        return imgView
    }()
    var profileImageView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "profile_icon")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.clipsToBounds = true
        return imgView
    }()
    var rightImageView: UIImageView = {
        let imgView = UIImageView()
        imgView.image = UIImage(named: "messaging")
        imgView.contentMode = .scaleAspectFit
        imgView.translatesAutoresizingMaskIntoConstraints = false
        imgView.clipsToBounds = true
        return imgView
    }()
 
    @objc func handleGesture(_ gesture: UISwipeGestureRecognizer) {
        
        switch gesture.direction {
            case .right:
                print("Swiped right")
                let settingVC =  SettingsViewController()
                settingVC.modalPresentationStyle = .custom
                settingVC.modalTransitionStyle = .crossDissolve
                self.present(settingVC, animated: true, completion: nil)
            
            case .down:
                print("Swiped down")
            case .left:
                print("Swiped left")
                let connectVC =  ConnectionViewController()
                connectVC.modalPresentationStyle = .custom
                connectVC.modalTransitionStyle = .crossDissolve
                self.present(connectVC, animated: true, completion: nil)
            case .up:
                print("Swiped up")
            default:
                break
        }
        /**
        **/
        
    }

    func setupViews() {
        view.addSubview(navBar)
        navBar.addSubview(titleImageView)
        navBar.addSubview(profileImageView)
        navBar.addSubview(rightImageView)
        
        navBar.setBackgroundImage(UIImage(named: ""), for: .default)
        navBar.shadowImage = UIImage()
        
        navBar.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor).isActive = true
        navBar.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        navBar.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        navBar.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        titleImageView.topAnchor.constraint(equalTo: navBar.topAnchor).isActive = true
        titleImageView.centerXAnchor.constraint(equalTo: navBar.centerXAnchor).isActive = true
        titleImageView.widthAnchor.constraint(equalToConstant: 150).isActive = true
        titleImageView.heightAnchor.constraint(equalToConstant: 40).isActive = true
        
        profileImageView.topAnchor.constraint(equalTo: navBar.topAnchor).isActive = true
        profileImageView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        profileImageView.centerYAnchor.constraint(equalTo: navBar.centerYAnchor).isActive = true
        profileImageView.widthAnchor.constraint(equalToConstant: 80).isActive = true
        profileImageView.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        rightImageView.topAnchor.constraint(equalTo: navBar.topAnchor).isActive = true
        rightImageView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        rightImageView.centerYAnchor.constraint(equalTo: navBar.centerYAnchor).isActive = true
        rightImageView.widthAnchor.constraint(equalToConstant: 80).isActive = true
        rightImageView.heightAnchor.constraint(equalToConstant: 20).isActive = true
    }

    
}
