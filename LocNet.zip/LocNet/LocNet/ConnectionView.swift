//
//  ConnectionView.swift
//  LocNet
//
//  Created by Gilchrist Toh on 1/11/19.
//  Copyright © 2019 Gilchrist Toh. All rights reserved.
//

import UIKit

class ConnectionView: UIViewController, UINavigationControllerDelegate, UITableViewDelegate, UITableViewDataSource {

    var messages: [String:UIImage] = ["Vibrance Music":#imageLiteral(resourceName: "music_guy"),"Gilly Toh":#imageLiteral(resourceName: "cheesy"),"Constance Toh":#imageLiteral(resourceName: "kratos"), "Thanos The Man":#imageLiteral(resourceName: "thanos"),"Ephraim Nyongha":#imageLiteral(resourceName: "gow4"), "Gilchrist Johnson":#imageLiteral(resourceName: "google") ]
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 6
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        cell = tableView.dequeueReusableCell(withIdentifier: "message", for: indexPath)
        cell.textLabel?.textAlignment = .center
        cell.heightAnchor.constraint(equalToConstant: 90).isActive = true
        cell.textLabel?.text = Array(messages.keys)[indexPath.row]
        cell.selectionStyle = .none
        cell.separatorInset = .zero
        
        let cellImg: UIImageView = UIImageView(frame: CGRect(x: 10, y: 15, width: 60, height: 60))
        cellImg.layer.borderColor = UIColor.black.cgColor
        cellImg.layer.borderWidth = 1
        cellImg.clipsToBounds = true
        cellImg.layer.cornerRadius = 30

        cellImg.image = Array(messages.values)[indexPath.row]
        cell.addSubview(cellImg)
        return cell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        connectionsTableView.rowHeight = UITableView.automaticDimension
        // Do any additional setup after loading the view.
        setupViews()
    }
    var searchBar: UISearchBar = {
        let searchBar = UISearchBar()
        searchBar.translatesAutoresizingMaskIntoConstraints = false
        return searchBar
    }()
    var textLabel: UILabel = {
        let nameLabel = UILabel()
        nameLabel.text = "CONNECTIONS"
        nameLabel.font = UIFont(name: "Helvetica Neue", size: 20)
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        nameLabel.textColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1)
        return nameLabel
    }()
    
    var gotoHomeButton: UIButton = {
        let button = UIButton()
        button.setImage(UIImage(named: "home"), for: .normal)
        button.layer.borderWidth = 1
        button.layer.cornerRadius = 20
        button.layer.borderColor = UIColor(red: 22/255.0, green: 23/255.0, blue: 94/255.0, alpha: 1).cgColor
        button.translatesAutoresizingMaskIntoConstraints = false
        return button
    }()
    
    func setupViews()
    {
        view.addSubview(textLabel)
        view.addSubview(searchBar)
        view.addSubview(gotoHomeButton)
        view.addSubview(connectionsTableView)
        
        connectionsTableView.delegate = self
        connectionsTableView.dataSource = self
        
        textLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 70).isActive = true
        textLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor).isActive = true
        
        searchBar.topAnchor.constraint(equalTo: textLabel.bottomAnchor, constant: 5).isActive = true
        searchBar.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        searchBar.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        searchBar.widthAnchor.constraint(equalTo: view.widthAnchor).isActive = true
        
        gotoHomeButton.topAnchor.constraint(equalTo: view.topAnchor, constant: 50).isActive = true
        gotoHomeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20).isActive = true
        gotoHomeButton.widthAnchor.constraint(equalToConstant: 40).isActive = true
        gotoHomeButton.heightAnchor.constraint(equalToConstant: 40).isActive = true
        //gotoHomeButton.addTarget(self, action: #selector(goHome), for: .touchUpInside)

        connectionsTableView.topAnchor.constraint(equalTo: searchBar.bottomAnchor).isActive = true
        connectionsTableView.leadingAnchor.constraint(equalTo: view.leadingAnchor).isActive = true
        connectionsTableView.trailingAnchor.constraint(equalTo: view.trailingAnchor).isActive = true
        connectionsTableView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20).isActive = true
        connectionsTableView.register(messageCell.self, forCellReuseIdentifier: "message")
        
    }
    
    var connectionsTableView: UITableView = {
        let tableView = UITableView()
        tableView.backgroundColor = UIColor.white
        tableView.translatesAutoresizingMaskIntoConstraints = false
        tableView.isScrollEnabled = false
        return tableView
    }()

    @objc func goHome() {
        print("Trying to go home")
        let homeVC = HomeView()
        homeVC.modalPresentationStyle = .custom
        homeVC.modalTransitionStyle = .crossDissolve
        self.present(homeVC, animated: true, completion: nil)
    }
}

class messageCell: UITableViewCell {
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init code not implemented")
    }
    
    
    
}
